import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize GoogleGenAI client lazily or when key exists
function getGenAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API Health
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    aiEnabled: !!process.env.GEMINI_API_KEY,
    timestamp: new Date().toISOString(),
    service: "CyberConfig AI - Security Compliance Engine (SIH26155)",
  });
});

// API: AI Deep Network Security Audit & Contextual Reasoning
app.post("/api/audit", async (req, res) => {
  try {
    const { rawConfig, vendor, deviceName } = req.body;
    if (!rawConfig) {
      return res.status(400).json({ error: "rawConfig is required" });
    }

    const ai = getGenAIClient();
    if (!ai) {
      return res.json({
        aiAnalysis: null,
        message: "Gemini API key not configured on server; using high-speed deterministic parser.",
      });
    }

    const prompt = `You are CyberConfig AI, an elite military-grade network security compliance auditor and parser expert for Smart India Hackathon (SIH 2026).
Analyze the following ${vendor || "network"} device configuration for ${deviceName || "Target Node"}.
Cross-examine against:
1. CIS Benchmark Level 1 & 2
2. NIST SP 800-53 Rev 5 (AC, SC, AU, IA controls)
3. DISA STIG for Network Devices
4. PCI-DSS v4.0

Here is the raw configuration:
\`\`\`
${rawConfig.slice(0, 8000)}
\`\`\`

Return a JSON object matching this schema:
{
  "executiveSummary": "Concise 2-3 sentence executive audit summary with overall risk posture",
  "threatLandscape": "Description of the highest priority threat vectors (e.g., cleartext exposure, perimeter bypass)",
  "canonicalHighlights": {
    "detectedVendor": "${vendor || "cisco"}",
    "osGuess": "string",
    "criticalVulnerabilitiesCount": number,
    "highVulnerabilitiesCount": number
  },
  "deepInsights": [
    {
      "findingTitle": "string",
      "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW",
      "cveOrStigRef": "string",
      "threatVector": "string",
      "detailedWhyRisky": "string",
      "exactVendorFixCli": "string (multiline commands)",
      "rollbackCli": "string (multiline commands)"
    }
  ]
}
Return ONLY valid JSON.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    let aiData = null;
    try {
      const text = response.text || "{}";
      aiData = JSON.parse(text);
    } catch {
      aiData = { executiveSummary: response.text };
    }

    res.json({
      aiAnalysis: aiData,
      isAiEnhanced: true,
    });
  } catch (error: any) {
    console.error("AI Audit error:", error);
    res.status(500).json({ error: error.message || "Failed to run AI audit" });
  }
});

// API: Self-Learning NLP Parser for Unknown / Novel Vendor Dialects
app.post("/api/parse-dialect", async (req, res) => {
  try {
    const { unknownConfigSnippet } = req.body;
    if (!unknownConfigSnippet) {
      return res.status(400).json({ error: "unknownConfigSnippet is required" });
    }

    const ai = getGenAIClient();
    if (!ai) {
      return res.json({
        learnedRecord: {
          vendorGuess: "Unknown/Generic CLI",
          interpretedIntent: "Management, Access-List, and Service Directives",
          canonicalCategory: "Universal Network Security Model",
          recommendedPolicy: "Enforce SSHv2, Deprecate Cleartext, Restrict Inbound Access",
          confidenceScore: 0.88,
          aiNotes: "Offline heuristic parser active.",
        },
      });
    }

    const prompt = `You are CyberConfig AI's Self-Learning NLP Parser module.
A network engineer provided an unknown or proprietary network configuration syntax that does not match standard Cisco/Juniper/Fortinet CLI formats.

Config snippet:
\`\`\`
${unknownConfigSnippet.slice(0, 4000)}
\`\`\`

Analyze the syntax tokens, extract security semantics, and output a JSON object:
{
  "vendorGuess": "Probable vendor/OS name (e.g. MikroTik, VyOS, Huawei VRP, Allied Telesis, Aruba, Check Point, pfSense, OpenWrt, or Custom Dialect)",
  "interpretedIntent": "Semantic explanation of what this config stanza controls",
  "canonicalCategory": "Authentication | Access Control | Cryptography | Logging | Network Perimeter",
  "identifiedRisks": ["list of potential security risks in this snippet"],
  "canonicalModelMapping": {
    "managementProtocol": "string",
    "accessRules": "string",
    "authenticationState": "string"
  },
  "recommendedHardeningPolicy": "Exact recommended hardening CLI commands adapted for this syntax",
  "confidenceScore": number (between 0.0 and 1.0)
}
Return ONLY valid JSON.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({ learnedRecord: parsed });
  } catch (error: any) {
    console.error("Dialect parse error:", error);
    res.status(500).json({ error: error.message || "Dialect parse failed" });
  }
});

// API: Interactive Network Security Copilot
app.post("/api/copilot", async (req, res) => {
  try {
    const { message, history, currentConfigContext } = req.body;
    if (!message) {
      return res.status(400).json({ error: "message is required" });
    }

    const ai = getGenAIClient();
    if (!ai) {
      return res.json({
        reply: `[CyberConfig Copilot - Offline Mode] Regarding your query: "${message}". In standard network hardening (CIS / NIST SP 800-53 / DISA STIG), always ensure all unencrypted services (Telnet port 23, HTTP port 80) are disabled in favor of SSHv2 (AES-GCM ciphers) and HTTPS (TLS 1.3). To enable full AI reasoning capabilities, provide GEMINI_API_KEY in the environment.`,
      });
    }

    const systemInstruction = `You are CyberConfig AI Copilot, an expert military & enterprise network cybersecurity auditor built for Smart India Hackathon (SIH 2026).
You specialize in multi-vendor network hardening (Cisco IOS-XE/XR, Juniper Junos, Fortinet FortiOS, Palo Alto PAN-OS, Arista, MikroTik, Linux iptables/nftables), CIS Benchmarks, NIST SP 800-53, DISA STIG, and PCI-DSS compliance.
Provide clear, authoritative, syntax-accurate answers with code snippets, security rationale, and compliance citations. Keep tone professional, encouraging, and technically precise.`;

    const contents = [];
    if (currentConfigContext) {
      contents.push({
        role: "user",
        parts: [{ text: `Current Active Configuration Context:\n\`\`\`\n${currentConfigContext.slice(0, 3000)}\n\`\`\`` }],
      });
      contents.push({
        role: "model",
        parts: [{ text: "Understood. I have loaded your current network configuration context and am ready to answer audit and compliance questions." }],
      });
    }

    if (history && Array.isArray(history)) {
      for (const msg of history.slice(-6)) {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.content }],
        });
      }
    }

    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents,
      config: {
        systemInstruction,
      },
    });

    res.json({ reply: response.text });
  } catch (error: any) {
    console.error("Copilot error:", error);
    res.status(500).json({ error: error.message || "Failed to generate copilot reply" });
  }
});

// Vite middleware for dev or static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CyberConfig AI Server running on http://localhost:${PORT}`);
  });
}

startServer();
