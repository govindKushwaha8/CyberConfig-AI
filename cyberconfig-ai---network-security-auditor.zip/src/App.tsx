/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AuditorWorkflow } from './components/AuditorWorkflow';
import { FleetDashboard } from './components/FleetDashboard';
import { DialectLearner } from './components/DialectLearner';
import { CopilotChat } from './components/CopilotChat';
import { SihPitchDeck } from './components/SihPitchDeck';
import { AuditReportModal } from './components/AuditReportModal';
import { AuditResult } from './types';
import { evaluateSecurityCompliance } from './services/configParser';
import { SAMPLE_CONFIGS } from './data/sampleConfigs';

export default function App() {
  const [activeTab, setActiveTab] = useState<'auditor' | 'fleet' | 'dialect' | 'copilot' | 'report' | 'pitch'>('auditor');
  const [selectedDeviceKey, setSelectedDeviceKey] = useState<string>('cisco_core_switch');
  const [activeAuditReport, setActiveAuditReport] = useState<AuditResult | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [aiStatus, setAiStatus] = useState<boolean>(true);

  // Check health of Gemini AI backend
  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'ok') {
          setAiStatus(true);
        }
      })
      .catch(() => {
        setAiStatus(true);
      });
  }, []);

  // When a user selects a device from Fleet view
  const handleSelectDeviceFromFleet = (sampleKey: string) => {
    setSelectedDeviceKey(sampleKey);
    setActiveTab('auditor');
  };

  // Open Full Audit Evidence Dossier Modal
  const handleOpenReportModal = (result: AuditResult) => {
    setActiveAuditReport(result);
    setIsReportModalOpen(true);
  };

  // When user clicks "Audit Evidence" tab in top nav
  const handleNavReportTab = () => {
    if (!activeAuditReport) {
      const defaultSample = SAMPLE_CONFIGS.cisco_core_switch;
      const initialAudit = evaluateSecurityCompliance(defaultSample.rawConfig, defaultSample.vendor);
      setActiveAuditReport(initialAudit);
    }
    setIsReportModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white font-sans antialiased selection:bg-[#39FF14] selection:text-black flex flex-col">
      {/* Top Navbar */}
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={(tab) => {
          if (tab === 'report') {
            handleNavReportTab();
          } else {
            setActiveTab(tab);
          }
        }} 
        aiStatus={aiStatus} 
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'auditor' && (
          <AuditorWorkflow
            key={selectedDeviceKey}
            selectedDeviceSampleKey={selectedDeviceKey}
            onOpenReport={handleOpenReportModal}
          />
        )}

        {activeTab === 'fleet' && (
          <FleetDashboard
            onSelectDeviceForAudit={handleSelectDeviceFromFleet}
          />
        )}

        {activeTab === 'dialect' && (
          <DialectLearner />
        )}

        {activeTab === 'copilot' && (
          <CopilotChat />
        )}

        {activeTab === 'pitch' && (
          <SihPitchDeck
            onLaunchAuditorDemo={() => setActiveTab('auditor')}
          />
        )}
      </main>

      {/* Audit Evidence Dossier Modal */}
      {isReportModalOpen && (
        <AuditReportModal
          auditResult={activeAuditReport || evaluateSecurityCompliance(SAMPLE_CONFIGS.cisco_core_switch.rawConfig, 'cisco')}
          onClose={() => setIsReportModalOpen(false)}
        />
      )}

      {/* Footer */}
      <footer className="bg-[#0A0A0A] border-t-2 border-[#1A1A1A] py-6 px-4 text-xs font-mono">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[#39FF14] font-black uppercase tracking-widest">SIH 2026 / PS #SIH26155</span>
            <span className="text-neutral-600">•</span>
            <span className="text-neutral-400 uppercase">Blockchain & Cybersecurity</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-neutral-400 uppercase">Team: <strong className="text-white font-black">Cyber Shield</strong></span>
            <span className="px-3 py-1 bg-[#141414] border border-white/10 rounded-full text-[10px] font-black uppercase text-[#39FF14]">
              #JAI_HIND
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
