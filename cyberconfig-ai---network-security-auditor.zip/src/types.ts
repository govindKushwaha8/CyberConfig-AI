export type VendorType = 'cisco' | 'juniper' | 'fortinet' | 'paloalto' | 'mikrotik' | 'arista' | 'unknown';

export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export type ComplianceFramework = 'CIS_BENCHMARKS' | 'NIST_SP800_53' | 'DISA_STIG' | 'PCI_DSS';

export interface ComplianceControlMapping {
  framework: ComplianceFramework;
  frameworkName: string;
  controlId: string;
  controlTitle: string;
}

export interface SecurityFinding {
  id: string;
  title: string;
  severity: Severity;
  category: 'Access Control' | 'Authentication & AAA' | 'Cryptography & Protocols' | 'Logging & Monitoring' | 'Service Hardening' | 'Network Exposure';
  evidence: string;
  lineNumber?: number;
  explanation: {
    what: string;
    why: string;
    impact: string;
    threatVector: string;
  };
  remediation: {
    commands: string[];
    explanation: string;
    rollbackCommands: string[];
  };
  controlMappings: ComplianceControlMapping[];
  confidence: number;
  approved?: boolean;
}

export interface CanonicalSecurityModel {
  vendor: VendorType;
  hostname?: string;
  osVersion?: string;
  management: {
    telnetEnabled: boolean;
    sshEnabled: boolean;
    sshV2Only: boolean;
    httpServerEnabled: boolean;
    httpsServerEnabled: boolean;
    loginBannerConfigured: boolean;
    sessionTimeoutMins?: number;
  };
  authentication: {
    passwordEncryptionEnabled: boolean;
    enableSecretConfigured: boolean;
    weakPasswordsDetected: boolean;
    aaaConfigured: boolean;
    tacacsOrRadius: boolean;
    rootLoginDirectSSH?: boolean;
  };
  loggingMonitoring: {
    syslogServerConfigured: boolean;
    loggingLevel?: string;
    ntpConfigured: boolean;
    ntpAuthenticated: boolean;
    snmpEnabled: boolean;
    snmpVersion: 'v1' | 'v2c' | 'v3' | 'none';
    weakSnmpCommunity: boolean;
  };
  accessControl: {
    overPermissiveAclFound: boolean;
    anyAnyRulesCount: number;
    insecurePortsOpen: number[];
  };
  cryptography: {
    weakCiphersAllowed: boolean;
    tlsVersion?: string;
    cryptoKeySize?: number;
  };
  summaryStats: {
    totalRulesParsed: number;
    unrecognizedSyntaxLines: number;
    normalizationConfidence: number;
  };
}

export interface AuditResult {
  id: string;
  timestamp: string;
  targetDeviceName: string;
  vendor: VendorType;
  complianceScore: number; // 0 - 100
  complianceGrade: 'A' | 'B' | 'C' | 'D' | 'F';
  riskScore: number; // 0 - 100
  riskLevel: Severity;
  findings: SecurityFinding[];
  frameworkScores: {
    CIS_BENCHMARKS: number;
    NIST_SP800_53: number;
    DISA_STIG: number;
    PCI_DSS: number;
  };
  canonicalModel: CanonicalSecurityModel;
  rawConfig: string;
  remediatedConfig?: string;
  auditEvidenceHash: string;
  summaryText: string;
  isAiEnhanced: boolean;
}

export interface FleetDevice {
  id: string;
  name: string;
  ip: string;
  vendor: VendorType;
  model: string;
  location: string;
  sector: 'Banking' | 'Defense' | 'Enterprise' | 'Data Center' | 'Healthcare' | 'Government';
  lastScanned: string;
  complianceScore: number;
  criticalIssues: number;
  highIssues: number;
  mediumIssues: number;
  lowIssues: number;
  status: 'Compliant' | 'At Risk' | 'Non-Compliant';
  sampleConfigKey: string;
}

export interface DialectLearningRecord {
  id: string;
  vendorGuess: string;
  originalSyntax: string;
  interpretedIntent: string;
  canonicalCategory: string;
  recommendedPolicy: string;
  confidenceScore: number;
  learnedAt: string;
  verifiedByAnalyst: boolean;
}
