import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Bot, 
  User, 
  Terminal, 
  RefreshCw, 
  ShieldCheck, 
  Copy, 
  Check, 
  HelpCircle,
  Award
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export const CopilotChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm-1',
      role: 'assistant',
      content: `Hello! I am **CyberConfig AI Copilot**, your military-grade network security and compliance auditor for Smart India Hackathon (SIH 2026).\n\nI can assist you with:\n- **Multi-Vendor Hardening:** Cisco (IOS-XE/NX-OS), Juniper (Junos), Fortinet (FortiOS), Palo Alto (PAN-OS), MikroTik, and Arista.\n- **Compliance Frameworks:** CIS Benchmarks, NIST SP 800-53 Rev 5, DISA STIG, PCI-DSS v4.0.\n- **ACL & Crypto Audits:** Debugging over-permissive access control rules, weak SSH/TLS ciphers, and SNMPv3 migration.\n- **Remediation & Rollback:** Generating syntax-accurate CLI scripts.\n\nHow can I help audit or secure your network today?`,
      timestamp: 'Just now'
    }
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (userPrompt?: string) => {
    const promptToSend = userPrompt || input;
    if (!promptToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: promptToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!userPrompt) setInput('');
    setIsLoading(true);

    try {
      const chatHistory = messages.map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        content: m.content
      }));

      const response = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptToSend,
          history: chatHistory
        })
      });

      const data = await response.json();
      const botMsg: ChatMessage = {
        id: `b-${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'Analysis completed.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      console.error('Copilot error:', err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: 'I encountered an error connecting to the AI backend. Please verify that the server is active.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const quickPrompts = [
    'How do I harden Cisco IOS-XE against DISA STIG NET-045?',
    'What is the difference between CIS Benchmark Level 1 vs Level 2 for Firewalls?',
    'Generate syntax to replace SNMPv2 cleartext with SNMPv3 on Juniper Junos',
    'How does CyberConfig AI prevent blind auto-changes during remediation?'
  ];

  return (
    <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl shadow-2xl flex flex-col h-[740px] overflow-hidden">
      {/* Header */}
      <div className="bg-[#0A0A0A] px-6 py-4 border-b-2 border-[#1A1A1A] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#141414] border-2 border-[#39FF14]/40 flex items-center justify-center shadow-md">
            <Sparkles className="w-5 h-5 text-[#39FF14]" />
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-tight text-white flex items-center gap-2">
              CyberConfig AI Security Copilot
              <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-[#39FF14]/15 text-[#39FF14] font-black border border-[#39FF14]/30 uppercase font-mono">
                Gemini 3.7 Online
              </span>
            </h3>
            <p className="text-[11px] text-neutral-400">
              Interactive Network Hardening & Compliance Advisor
            </p>
          </div>
        </div>

        <span className="text-xs text-neutral-400 font-mono hidden sm:inline font-bold uppercase">
          Model: gemini-3.7-flash
        </span>
      </div>

      {/* Message Stream */}
      <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-[#0A0A0A]">
        {messages.map((m) => {
          const isBot = m.role === 'assistant';
          return (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${isBot ? 'justify-start' : 'justify-end'}`}
            >
              {isBot && (
                <div className="w-9 h-9 rounded-xl bg-[#141414] border-2 border-[#39FF14]/30 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4 text-[#39FF14]" />
                </div>
              )}

              <div
                className={`max-w-[82%] rounded-2xl p-5 text-xs leading-relaxed ${
                  isBot
                    ? 'bg-[#141414] border-2 border-[#1A1A1A] text-neutral-200 shadow-xl'
                    : 'bg-[#39FF14] text-black font-semibold shadow-xl'
                }`}
              >
                <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-white/10 text-[11px] opacity-80 uppercase font-mono font-bold">
                  <span>{isBot ? 'CyberConfig AI' : 'Security Auditor'}</span>
                  <span>{m.timestamp}</span>
                </div>

                <div className="whitespace-pre-wrap font-sans space-y-2 text-[13px] leading-relaxed">
                  {m.content}
                </div>

                {isBot && (
                  <div className="mt-4 pt-2.5 border-t border-[#1A1A1A] flex items-center justify-end">
                    <button
                      onClick={() => handleCopy(m.content, m.id)}
                      className="flex items-center gap-1.5 text-[11px] text-neutral-400 hover:text-[#39FF14] transition-colors font-mono font-bold uppercase"
                    >
                      {copiedId === m.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-[#39FF14]" />
                          <span className="text-[#39FF14]">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Response</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {!isBot && (
                <div className="w-9 h-9 rounded-xl bg-white text-black font-black flex items-center justify-center shrink-0 mt-0.5 shadow-md">
                  <User className="w-4 h-4 text-black" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#141414] border-2 border-[#39FF14]/30 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-[#39FF14] animate-pulse" />
            </div>
            <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-4 text-xs text-neutral-300 flex items-center gap-2.5 font-mono">
              <RefreshCw className="w-4 h-4 animate-spin text-[#39FF14]" />
              <span>Analyzing compliance rules and synthesizing security guidance...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts */}
      <div className="px-6 py-2.5 bg-[#0A0A0A] border-t-2 border-[#1A1A1A] flex items-center gap-2 overflow-x-auto">
        <span className="text-[11px] text-neutral-400 shrink-0 font-bold uppercase flex items-center gap-1.5 font-mono">
          <HelpCircle className="w-3.5 h-3.5 text-[#39FF14]" />
          Quick Ask:
        </span>
        {quickPrompts.map((q, i) => (
          <button
            key={i}
            onClick={() => handleSend(q)}
            className="px-3 py-1 rounded-lg bg-[#141414] hover:bg-neutral-900 text-neutral-300 hover:text-white text-[11px] border border-[#1A1A1A] hover:border-[#39FF14]/40 shrink-0 transition-colors font-mono"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-5 bg-[#0A0A0A] border-t-2 border-[#1A1A1A]">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about Cisco/Juniper hardening, CIS benchmarks, DISA STIG, or paste an ACL to audit..."
            className="flex-1 bg-[#141414] text-white text-xs px-4 py-3 rounded-xl border-2 border-[#1A1A1A] focus:outline-none focus:border-[#39FF14] placeholder-neutral-500 font-mono"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="px-6 py-3 rounded-xl bg-[#39FF14] hover:bg-[#32e010] text-black text-xs font-black uppercase tracking-wider shadow-[0_0_15px_rgba(57,255,20,0.2)] transition-all disabled:opacity-50 flex items-center gap-2"
          >
            <span>Ask Copilot</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
