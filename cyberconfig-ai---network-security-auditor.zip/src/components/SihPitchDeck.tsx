import React, { useState } from 'react';
import { 
  Presentation, 
  ChevronLeft, 
  ChevronRight, 
  Award, 
  ShieldCheck, 
  Layers, 
  Activity, 
  Building2, 
  CheckCircle2, 
  Sparkles,
  BookOpen,
  ArrowRight,
  Landmark,
  Cpu
} from 'lucide-react';

interface SihPitchDeckProps {
  onLaunchAuditorDemo: () => void;
}

export const SihPitchDeck: React.FC<SihPitchDeckProps> = ({ onLaunchAuditorDemo }) => {
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 6;

  const nextSlide = () => setCurrentSlide(prev => Math.min(totalSlides, prev + 1));
  const prevSlide = () => setCurrentSlide(prev => Math.max(1, prev - 1));

  return (
    <div className="space-y-6">
      {/* Slide Navigation Header */}
      <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-4 shadow-2xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#0A0A0A] border-2 border-[#39FF14]/40 flex items-center justify-center">
            <Presentation className="w-5 h-5 text-[#39FF14]" />
          </div>
          <div>
            <h2 className="text-sm font-black uppercase tracking-tight text-white flex items-center gap-2">
              SIH 2026 Interactive Submission Deck
              <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-[#39FF14]/15 text-[#39FF14] font-black border border-[#39FF14]/30 uppercase font-mono">
                Pre-Qualifier Round
              </span>
            </h2>
            <p className="text-[11px] text-neutral-400">
              Interactive architectural and feasibility presentation corresponding to team Cyber Shield&apos;s PPT submission.
            </p>
          </div>
        </div>

        {/* Slide Counter & Buttons */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-[#0A0A0A] px-3.5 py-1.5 rounded-xl border border-[#1A1A1A] text-xs font-mono">
            <span className="text-[#39FF14] font-black uppercase">Slide {currentSlide}</span>
            <span className="text-neutral-500 font-bold">/ {totalSlides}</span>
          </div>

          <button
            onClick={prevSlide}
            disabled={currentSlide === 1}
            className="p-2 rounded-xl bg-[#0A0A0A] hover:bg-neutral-900 border border-[#1A1A1A] text-neutral-300 disabled:opacity-40 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={nextSlide}
            disabled={currentSlide === totalSlides}
            className="p-2 rounded-xl bg-[#0A0A0A] hover:bg-neutral-900 border border-[#1A1A1A] text-neutral-300 disabled:opacity-40 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={onLaunchAuditorDemo}
            className="ml-2 px-3.5 py-1.5 rounded-xl bg-[#39FF14] hover:bg-[#32e010] text-black text-xs font-black uppercase tracking-wider shadow-[0_0_10px_rgba(57,255,20,0.2)] transition-all flex items-center gap-1.5"
          >
            <span>Live MVP Auditor</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Slide Visual Container */}
      <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-3xl p-6 sm:p-8 shadow-2xl min-h-[580px] flex flex-col justify-between">
        {/* SLIDE 1: Title Page */}
        {currentSlide === 1 && (
          <div className="space-y-6 my-auto text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#39FF14]/15 text-[#39FF14] border border-[#39FF14]/30 text-xs font-black uppercase font-mono">
              <Award className="w-4 h-4 text-[#39FF14]" />
              SMART INDIA HACKATHON 2026
            </div>

            <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight leading-tight uppercase">
              AI-Driven Multi-Vendor Network Security Compliance Auditor
            </h1>
            <p className="text-[#39FF14] font-mono text-base font-black uppercase tracking-wider">
              Product: CyberConfig AI
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-left font-mono text-xs max-w-xl mx-auto bg-[#0A0A0A] p-5 rounded-2xl border-2 border-[#1A1A1A]">
              <div>
                <span className="text-neutral-500 block text-[10px] uppercase font-bold">PROBLEM STATEMENT ID</span>
                <span className="text-white font-black text-sm">SIH26155</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[10px] uppercase font-bold">THEME</span>
                <span className="text-[#39FF14] font-black uppercase">Blockchain & Cybersecurity</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[10px] uppercase font-bold">PS CATEGORY</span>
                <span className="text-white font-bold uppercase">Software</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[10px] uppercase font-bold">TEAM NAME</span>
                <span className="text-[#39FF14] font-black text-sm uppercase">Cyber Shield</span>
              </div>
            </div>

            <p className="text-xs text-neutral-400 italic max-w-lg mx-auto leading-relaxed">
              &quot;A vendor-agnostic AI auditor that understands network configurations, detects security/compliance gaps, explains risks, recommends fixes, verifies remediation, and learns from previously unseen configurations.&quot;
            </p>
          </div>
        )}

        {/* SLIDE 2: Proposed Solution */}
        {currentSlide === 2 && (
          <div className="space-y-6">
            <div className="border-b-2 border-[#1A1A1A] pb-3">
              <span className="text-[#39FF14] font-black text-xs uppercase tracking-widest font-mono">Slide 2 / Proposed Solution</span>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white mt-1">CyberConfig AI Solution Architecture</h2>
            </div>

            {/* Workflow 6-Boxes */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
              {[
                { title: '1. Multi-Vendor Input', desc: 'Cisco, Juniper, Fortinet, Palo Alto, Unknown formats' },
                { title: '2. AI Normalization', desc: 'LLM/NLP parses into canonical security model' },
                { title: '3. Compliance Engine', desc: 'CIS Benchmarks, NIST SP 800-53, DISA STIG' },
                { title: '4. AI Risk Assessment', desc: 'Critical, High, Medium, Low prioritization' },
                { title: '5. Explainable Fixes', desc: 'Why it is risky + exact CLI commands' },
                { title: '6. Re-Scan & Verify', desc: 'Closed-loop verification of improved score' },
              ].map((b, i) => (
                <div key={i} className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-1">
                  <div className="font-black uppercase tracking-tight text-[#39FF14] text-[11px]">{b.title}</div>
                  <p className="text-[11px] text-neutral-400 leading-tight">{b.desc}</p>
                </div>
              ))}
            </div>

            {/* Unique Innovations Box */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-5 rounded-2xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-1.5">
                <div className="font-black uppercase tracking-tight text-white text-xs flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#39FF14]" />
                  Self-Learning Parser
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Learns unknown vendor syntax through analyst feedback and continuously expands rule coverage.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-1.5">
                <div className="font-black uppercase tracking-tight text-white text-xs flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#39FF14]" />
                  Vendor-Agnostic Intelligence
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Converts heterogeneous configs into a unified intermediate security model for standard auditing.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-1.5">
                <div className="font-black uppercase tracking-tight text-white text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#39FF14]" />
                  Closed-Loop Verification
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Detect ➔ Recommend Fix ➔ Re-scan ➔ Verify continuous compliance improvement mathematically.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* SLIDE 3: Technical Approach */}
        {currentSlide === 3 && (
          <div className="space-y-6">
            <div className="border-b-2 border-[#1A1A1A] pb-3">
              <span className="text-[#39FF14] font-black text-xs uppercase tracking-widest font-mono">Slide 3 / Technical Approach</span>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white mt-1">Technical Architecture & Decision Layers</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <span className="px-2.5 py-0.5 rounded-full bg-[#39FF14]/15 text-[#39FF14] font-black font-mono text-[10px] uppercase">
                  AI DECISION LAYER
                </span>
                <h4 className="font-black uppercase text-white">Hybrid Intelligence</h4>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  LLM interprets unseen syntax and context; deterministic Policy-as-Code engine enforces security controls.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-black font-mono text-[10px] uppercase">
                  RISK ENGINE
                </span>
                <h4 className="font-black uppercase text-white">Evidence-Based Scoring</h4>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  Asset criticality + exploitability + exposure score = explainable Critical, High, Medium, Low prioritization.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <span className="px-2.5 py-0.5 rounded-full bg-[#39FF14]/15 text-[#39FF14] font-black font-mono text-[10px] uppercase">
                  REMEDIATION GUARDRAILS
                </span>
                <h4 className="font-black uppercase text-white">Human-in-the-Loop</h4>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  Recommendation ➔ dry-run ➔ human approval ➔ apply ➔ verification ➔ rollback if regression. No blind auto-changes.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <span className="px-2.5 py-0.5 rounded-full bg-[#39FF14]/15 text-[#39FF14] font-black font-mono text-[10px] uppercase">
                  CONTINUOUS LEARNING
                </span>
                <h4 className="font-black uppercase text-white">Closed-Loop Feedback</h4>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  Analyst feedback + remediation outcome yields parser/policy improvements for higher future accuracy.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* SLIDE 4: Feasibility & Viability */}
        {currentSlide === 4 && (
          <div className="space-y-6">
            <div className="border-b-2 border-[#1A1A1A] pb-3">
              <span className="text-[#39FF14] font-black text-xs uppercase tracking-widest font-mono">Slide 4 / Feasibility & Viability</span>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white mt-1">Practical, Secure, and Scalable for Real Deployment</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <div className="font-black uppercase text-[#39FF14]">Technical Feasibility</div>
                <p className="text-neutral-300 text-[11px] leading-relaxed">
                  Read-only ingestion via SSH/API/Export (zero production change during audit). Multi-vendor parsing using NLP + Policy-as-Code.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <div className="font-black uppercase text-[#39FF14]">Operational Viability</div>
                <p className="text-neutral-300 text-[11px] leading-relaxed">
                  Designed for SOC, Network Ops & Audit teams. Simple UI, actionable insights, integrates with SIEM/ITSM.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <div className="font-black uppercase text-amber-400">Security & Trust</div>
                <p className="text-neutral-300 text-[11px] leading-relaxed">
                  All data encrypted in transit & at rest. Role-based access control (RBAC), full audit trail & versioning.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2">
                <div className="font-black uppercase text-white">Scalability & Cost</div>
                <p className="text-neutral-300 text-[11px] leading-relaxed">
                  Modular microservices architecture, deployable on-prem or cloud. High ROI through risk reduction & automation.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* SLIDE 5: Impact & Uniqueness */}
        {currentSlide === 5 && (
          <div className="space-y-6">
            <div className="border-b-2 border-[#1A1A1A] pb-3">
              <span className="text-[#39FF14] font-black text-xs uppercase tracking-widest font-mono">Slide 5 / Impact, Uniqueness & Deployment</span>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white mt-1">Measurable Real-World Impact</h2>
            </div>

            {/* Impact Metric Ribbons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
                <div className="text-4xl font-black text-[#39FF14] tracking-tighter">70%+</div>
                <div className="text-xs text-white font-black uppercase mt-1">Audit Time Saved</div>
                <div className="text-[10px] text-neutral-500 uppercase font-mono">Manual review reduction</div>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
                <div className="text-4xl font-black text-[#39FF14] tracking-tighter">80%+</div>
                <div className="text-xs text-white font-black uppercase mt-1">Risk Reduction</div>
                <div className="text-[10px] text-neutral-500 uppercase font-mono">High-risk misconfigs remediated</div>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
                <div className="text-4xl font-black text-white tracking-tighter">90%+</div>
                <div className="text-xs text-white font-black uppercase mt-1">Detection Accuracy</div>
                <div className="text-[10px] text-neutral-500 uppercase font-mono">Across multi-vendor rulesets</div>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
                <div className="text-4xl font-black text-[#39FF14] tracking-tighter">100%</div>
                <div className="text-xs text-white font-black uppercase mt-1">Evidence Trail</div>
                <div className="text-[10px] text-neutral-500 uppercase font-mono">Cryptographically signed logs</div>
              </div>
            </div>

            {/* Path to Scale */}
            <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
              <span className="text-[10px] font-black uppercase text-neutral-400 block mb-2 font-mono tracking-wider">
                PATH TO NATIONAL SCALE FOR INDIA:
              </span>
              <div className="flex flex-wrap items-center justify-between text-xs gap-2 font-mono font-bold">
                <span className="text-[#39FF14]">1. Prototype (Completed)</span>
                <span className="text-neutral-600">➔</span>
                <span className="text-white">2. Pilot (3-6 Months in BFSI/Defense)</span>
                <span className="text-neutral-600">➔</span>
                <span className="text-neutral-300">3. Enterprise (6-18 Months)</span>
                <span className="text-neutral-600">➔</span>
                <span className="text-[#39FF14]">4. National Scale (Multi-tenant Cloud)</span>
              </div>
            </div>
          </div>
        )}

        {/* SLIDE 6: Research & References */}
        {currentSlide === 6 && (
          <div className="space-y-6">
            <div className="border-b-2 border-[#1A1A1A] pb-3">
              <span className="text-[#39FF14] font-black text-xs uppercase tracking-widest font-mono">Slide 6 / Research & Market Benching</span>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white mt-1">Research Standards & Market Benching</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-5 rounded-2xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2.5">
                <h4 className="font-black uppercase text-[#39FF14] flex items-center gap-2 text-sm">
                  <BookOpen className="w-4 h-4" />
                  Key Research References
                </h4>
                <ul className="space-y-2 text-neutral-300 text-[11px] leading-relaxed">
                  <li>• <strong className="text-white">SAMBHAV Platform:</strong> Indian Army indigenous secure communication platform.</li>
                  <li>• <strong className="text-white">Signal & Double Ratchet Protocol:</strong> Open-source E2E encryption architecture.</li>
                  <li>• <strong className="text-white">Wickr RAM:</strong> DOD-approved enterprise compliance & zero-knowledge messaging.</li>
                  <li>• <strong className="text-white">CIS Benchmarks & DISA STIGs:</strong> Defense network configuration hardening controls.</li>
                </ul>
              </div>

              <div className="p-5 rounded-2xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2.5">
                <h4 className="font-black uppercase text-[#39FF14] flex items-center gap-2 text-sm">
                  <Award className="w-4 h-4" />
                  Why CyberConfig AI Platform Wins
                </h4>
                <ul className="space-y-2 text-neutral-300 text-[11px] leading-relaxed">
                  <li>• <strong className="text-white">India-Hosted Sovereign Infrastructure:</strong> Designed for Indian defence & banking.</li>
                  <li>• <strong className="text-white">Zero Blind Auto-Changes:</strong> Strict human-in-the-loop validation & rollback.</li>
                  <li>• <strong className="text-white">Self-Learning Parser:</strong> Never breaks on un-indexed or proprietary vendor syntax.</li>
                  <li>• <strong className="text-white">Continuous Closed-Loop Audit:</strong> Automated proof of remediation.</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Slide Bottom Bar */}
        <div className="pt-4 border-t-2 border-[#1A1A1A] flex items-center justify-between text-xs text-neutral-400 font-mono">
          <span>Smart India Hackathon 2026 • PS ID: SIH26155</span>
          <span className="text-[#39FF14] font-black uppercase">Team Cyber Shield</span>
        </div>
      </div>
    </div>
  );
};
