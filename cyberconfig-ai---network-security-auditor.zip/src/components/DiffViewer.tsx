import React from 'react';
import { ArrowRight, CheckCircle2, ShieldAlert } from 'lucide-react';

interface DiffViewerProps {
  originalConfig: string;
  remediatedConfig: string;
  appliedCommands: string[];
}

export const DiffViewer: React.FC<DiffViewerProps> = ({
  originalConfig,
  remediatedConfig,
  appliedCommands
}) => {
  const origLines = originalConfig.split('\n');
  const remLines = remediatedConfig.split('\n');

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
          <h4 className="text-sm font-semibold text-white">Remediation Staging & Configuration Diff</h4>
          <span className="text-xs text-slate-400 font-mono">({appliedCommands.length} Approved Policies Injected)</span>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5 text-rose-400">
            <span className="w-3 h-3 rounded bg-rose-500/20 border border-rose-500/40 inline-flex items-center justify-center text-[10px]">-</span>
            <span>Vulnerable Stanza Removed</span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-3 h-3 rounded bg-emerald-500/20 border border-emerald-500/40 inline-flex items-center justify-center text-[10px]">+</span>
            <span>Hardened Security Applied</span>
          </div>
        </div>
      </div>

      {/* Applied Commands Summary Ribbon */}
      <div className="bg-slate-900/80 p-3 border-b border-slate-800/80 text-xs">
        <p className="text-slate-400 font-semibold mb-1.5 flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          Active Policy-as-Code Remediation Commands Staged for Deployment:
        </p>
        <div className="flex flex-wrap gap-1.5 font-mono text-[11px]">
          {appliedCommands.map((cmd, idx) => (
            <span 
              key={idx} 
              className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/30 text-emerald-300"
            >
              {cmd}
            </span>
          ))}
        </div>
      </div>

      {/* Split Code Diff Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 font-mono text-xs max-h-[480px] overflow-y-auto">
        {/* Left: Original Config */}
        <div className="p-3 bg-slate-950/60">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-slate-400 font-sans font-medium text-xs">
            <span className="flex items-center gap-1 text-rose-400">
              <ShieldAlert className="w-3.5 h-3.5" />
              Pre-Remediation (Audited State)
            </span>
            <span className="text-[11px] text-slate-500">{origLines.length} lines</span>
          </div>
          <div className="space-y-0.5 text-slate-300">
            {origLines.map((line, i) => {
              const isVulnerable = 
                line.includes('telnet') || 
                line.includes('permit ip any any') || 
                line.includes('community public') || 
                line.includes('no service password') ||
                line.includes('http server') ||
                line.includes('root-login allow');

              return (
                <div 
                  key={i} 
                  className={`flex items-start px-2 py-0.5 rounded ${
                    isVulnerable 
                      ? 'bg-rose-950/40 text-rose-200 border-l-2 border-rose-500' 
                      : 'hover:bg-slate-900/50'
                  }`}
                >
                  <span className="w-8 text-slate-600 text-right pr-3 select-none text-[10px]">{i + 1}</span>
                  <span className="break-all whitespace-pre-wrap">{line || ' '}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Hardened Config */}
        <div className="p-3 bg-slate-950/30">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-slate-400 font-sans font-medium text-xs">
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Post-Remediation (Hardened Candidate)
            </span>
            <span className="text-[11px] text-slate-500">{remLines.length} lines</span>
          </div>
          <div className="space-y-0.5 text-slate-300">
            {remLines.map((line, i) => {
              const isRemediated = 
                line.includes('transport input ssh') || 
                line.includes('service password-encryption') || 
                line.includes('deny ip any any') || 
                line.includes('SECURE_CORP_GRP v3') ||
                line.includes('secure-server') ||
                line.includes('root-login deny') ||
                line.includes('banner motd') ||
                line.includes('ntp authenticate');

              return (
                <div 
                  key={i} 
                  className={`flex items-start px-2 py-0.5 rounded ${
                    isRemediated 
                      ? 'bg-emerald-950/40 text-emerald-200 border-l-2 border-emerald-500' 
                      : 'hover:bg-slate-900/50'
                  }`}
                >
                  <span className="w-8 text-slate-600 text-right pr-3 select-none text-[10px]">{i + 1}</span>
                  <span className="break-all whitespace-pre-wrap">{line || ' '}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
