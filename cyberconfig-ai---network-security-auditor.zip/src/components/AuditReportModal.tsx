import React from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  X, 
  CheckCircle2, 
  ShieldCheck, 
  ShieldAlert, 
  Calendar, 
  Hash, 
  Server, 
  Award,
  Layers
} from 'lucide-react';
import { AuditResult } from '../types';

interface AuditReportModalProps {
  auditResult: AuditResult | null;
  onClose: () => void;
}

export const AuditReportModal: React.FC<AuditReportModalProps> = ({ auditResult, onClose }) => {
  if (!auditResult) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(auditResult, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `CyberConfig_AuditReport_${auditResult.targetDeviceName}_${auditResult.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden my-8 flex flex-col max-h-[90vh]">
        {/* Modal Top Actions */}
        <div className="bg-[#0A0A0A] px-6 py-4 border-b-2 border-[#1A1A1A] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#141414] border-2 border-[#39FF14]/40 flex items-center justify-center">
              <FileText className="w-4 h-4 text-[#39FF14]" />
            </div>
            <div>
              <h3 className="text-sm font-black uppercase tracking-tight text-white">
                Compliance Audit Evidence Dossier
              </h3>
              <p className="text-[11px] text-neutral-400 font-mono">
                Dossier ID: {auditResult.id} | SHA-256: {auditResult.auditEvidenceHash.slice(0, 16)}...
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#141414] hover:bg-neutral-900 text-neutral-200 text-xs font-bold uppercase tracking-wider border border-[#1A1A1A] transition-colors font-mono"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / PDF
            </button>

            <button
              onClick={handleDownloadJson}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#39FF14] hover:bg-[#32e010] text-black text-xs font-black uppercase tracking-wider shadow-[0_0_10px_rgba(57,255,20,0.2)] transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Export JSON
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-[#141414] hover:bg-neutral-900 text-neutral-400 hover:text-white transition-colors ml-1 border border-[#1A1A1A]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Report Canvas */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-neutral-300 font-sans bg-[#141414] printable-area">
          {/* Header Banner */}
          <div className="p-6 rounded-2xl bg-[#0A0A0A] border-2 border-[#1A1A1A] flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#39FF14]/15 text-[#39FF14] border border-[#39FF14]/30 uppercase font-mono">
                  SMART INDIA HACKATHON 2026
                </span>
                <span className="text-neutral-400 font-mono text-[11px] font-bold">PS: SIH26155</span>
              </div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white">
                CyberConfig AI Security Audit Certificate
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Multi-Vendor Automated Audit & Policy-as-Code Remediation Verification
              </p>
            </div>

            <div className="text-right font-mono text-[11px] space-y-1">
              <div className="text-neutral-400 flex items-center justify-end gap-1.5 font-bold">
                <Calendar className="w-3.5 h-3.5 text-[#39FF14]" />
                {auditResult.timestamp}
              </div>
              <div className="text-[#39FF14] font-black uppercase">STATUS: VERIFIED RECORD</div>
            </div>
          </div>

          {/* Device & Audit Metadata Table */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
              <span className="text-neutral-500 text-[10px] block uppercase font-bold">TARGET NODE</span>
              <span className="text-white font-black text-sm">{auditResult.targetDeviceName}</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
              <span className="text-neutral-500 text-[10px] block uppercase font-bold">VENDOR & OS</span>
              <span className="text-[#39FF14] font-black uppercase">{auditResult.vendor} (Normalized)</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
              <span className="text-neutral-500 text-[10px] block uppercase font-bold">COMPLIANCE SCORE</span>
              <span className={`text-base font-black tracking-tight ${auditResult.complianceScore >= 80 ? 'text-[#39FF14]' : 'text-rose-400'}`}>
                {auditResult.complianceScore}% (Grade {auditResult.complianceGrade})
              </span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A]">
              <span className="text-neutral-500 text-[10px] block uppercase font-bold">RESIDUAL RISK</span>
              <span className="text-white font-black">{auditResult.riskScore}/100 ({auditResult.riskLevel})</span>
            </div>
          </div>

          {/* Framework Conformity Summary */}
          <div className="p-5 rounded-2xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-3">
            <h4 className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#39FF14]" />
              Standard Compliance Control Matrices
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
              <div className="p-3 rounded-xl bg-[#141414] border border-[#1A1A1A]">
                <span className="text-[10px] text-neutral-400 block uppercase font-bold">CIS Benchmarks</span>
                <span className="text-base font-black text-[#39FF14]">{auditResult.frameworkScores.CIS_BENCHMARKS}%</span>
              </div>
              <div className="p-3 rounded-xl bg-[#141414] border border-[#1A1A1A]">
                <span className="text-[10px] text-neutral-400 block uppercase font-bold">NIST SP 800-53</span>
                <span className="text-base font-black text-[#39FF14]">{auditResult.frameworkScores.NIST_SP800_53}%</span>
              </div>
              <div className="p-3 rounded-xl bg-[#141414] border border-[#1A1A1A]">
                <span className="text-[10px] text-neutral-400 block uppercase font-bold">DISA STIG</span>
                <span className="text-base font-black text-[#39FF14]">{auditResult.frameworkScores.DISA_STIG}%</span>
              </div>
              <div className="p-3 rounded-xl bg-[#141414] border border-[#1A1A1A]">
                <span className="text-[10px] text-neutral-400 block uppercase font-bold">PCI-DSS v4.0</span>
                <span className="text-base font-black text-[#39FF14]">{auditResult.frameworkScores.PCI_DSS}%</span>
              </div>
            </div>
          </div>

          {/* Findings & Evidence Trail */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              Audited Findings & Evidence Log ({auditResult.findings.length} Items)
            </h4>

            {auditResult.findings.map((f, idx) => (
              <div key={f.id} className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#141414] border border-[#1A1A1A] text-neutral-400 flex items-center justify-center font-mono text-[10px] font-bold">
                      {idx + 1}
                    </span>
                    <span className="font-bold text-white text-xs">{f.title}</span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-rose-500/20 text-rose-300 border border-rose-500/40">
                    {f.severity}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] pt-1">
                  <div>
                    <span className="text-neutral-400 block font-bold uppercase text-[10px]">Config Evidence:</span>
                    <pre className="font-mono text-[10px] text-[#39FF14] bg-[#141414] border border-[#1A1A1A] p-2 rounded-lg mt-0.5 whitespace-pre-wrap">
                      {f.evidence}
                    </pre>
                  </div>
                  <div>
                    <span className="text-neutral-400 block font-bold uppercase text-[10px]">Security Rationale:</span>
                    <p className="text-neutral-300 mt-0.5 leading-relaxed font-sans">{f.explanation.why}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-[#1A1A1A] flex flex-wrap gap-1.5 font-mono text-[10px]">
                  <span className="text-neutral-500 font-bold uppercase">Controls:</span>
                  {f.controlMappings.map((m, i) => (
                    <span key={i} className="px-2 py-0.5 rounded-full bg-[#141414] text-[#39FF14] border border-[#1A1A1A] font-bold">
                      {m.controlId} ({m.framework})
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Cryptographic Audit Stamp */}
          <div className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] flex items-center justify-between text-xs font-mono text-neutral-400">
            <div>
              <div className="flex items-center gap-2 text-white font-bold">
                <Hash className="w-4 h-4 text-[#39FF14]" />
                Immutable Audit Trail Signature:
              </div>
              <span className="text-[11px] text-neutral-500 break-all">{auditResult.auditEvidenceHash}</span>
            </div>
            <div className="text-right">
              <span className="text-[#39FF14] font-black block uppercase">AUDIT VERIFIED</span>
              <span className="text-[10px] text-neutral-500 uppercase font-bold">Cyber Shield Engine v2.6</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
