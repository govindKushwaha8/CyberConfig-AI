import React, { useState } from 'react';
import { 
  Cpu, 
  Sparkles, 
  CheckCircle2, 
  Terminal, 
  ArrowRight, 
  Layers, 
  RefreshCw, 
  Send,
  BookOpen,
  Sliders,
  ShieldCheck,
  Award
} from 'lucide-react';
import { DialectLearningRecord } from '../types';

export const DialectLearner: React.FC = () => {
  const [snippet, setSnippet] = useState<string>(
`# Proprietary Telecom Network Gateway (Novel Dialect)
/system access-guard
enable telnet-service port=2300 permit-ip=any
set admin-auth type=plaintext secret="NOC_Master_2026"
set web-portal http-mode=unencrypted port=8080
enable syslog-stream target=10.200.5.10 port=514 protocol=udp
set filter-chain ingress action=pass-all`
  );

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [learnedData, setLearnedData] = useState<any>(null);
  const [history, setHistory] = useState<DialectLearningRecord[]>([
    {
      id: 'REC-01',
      vendorGuess: 'Huawei VRP / CloudEngine',
      originalSyntax: 'aaa \n local-user admin password simple Hua@2024 \n service-type telnet ssh',
      interpretedIntent: 'User authentication credentials stored without hash encryption and telnet enabled',
      canonicalCategory: 'Authentication & AAA',
      recommendedPolicy: 'local-user admin password irreversible-cipher StrongPass! \n service-type ssh',
      confidenceScore: 0.94,
      learnedAt: '15 mins ago',
      verifiedByAnalyst: true
    },
    {
      id: 'REC-02',
      vendorGuess: 'ArubaOS-CX / ProCurve',
      originalSyntax: 'snmp-server community "public" unrestricted \n no ssh authentication-retries',
      interpretedIntent: 'Cleartext SNMP read-write community enabled without rate-limiting',
      canonicalCategory: 'Logging & Monitoring',
      recommendedPolicy: 'snmpv3 user sec-audit auth sha-256 StrongAuth! priv aes-256 StrongPriv!',
      confidenceScore: 0.92,
      learnedAt: '40 mins ago',
      verifiedByAnalyst: true
    }
  ]);

  const handleLearnDialect = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/parse-dialect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unknownConfigSnippet: snippet })
      });
      const data = await response.json();
      setLearnedData(data.learnedRecord || data);

      // Add to history
      const newRec: DialectLearningRecord = {
        id: `REC-${Date.now().toString().slice(-4)}`,
        vendorGuess: data.learnedRecord?.vendorGuess || 'Novel Telecom Dialect',
        originalSyntax: snippet.split('\n').slice(0, 2).join(' '),
        interpretedIntent: data.learnedRecord?.interpretedIntent || 'Extracted Management & Ingress Directives',
        canonicalCategory: data.learnedRecord?.canonicalCategory || 'Universal Security Model',
        recommendedPolicy: data.learnedRecord?.recommendedHardeningPolicy || 'Enforce SSHv2, Disable Port 2300, Restrict Ingress',
        confidenceScore: data.learnedRecord?.confidenceScore || 0.91,
        learnedAt: 'Just now',
        verifiedByAnalyst: false
      };
      setHistory(prev => [newRec, ...prev]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-6 shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#0A0A0A] border-2 border-[#39FF14]/30 flex items-center justify-center">
            <Cpu className="w-6 h-6 text-[#39FF14]" />
          </div>
          <div>
            <h2 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2.5">
              Self-Learning NLP Parser & Novel Dialect Laboratory
              <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-[#39FF14]/15 text-[#39FF14] font-black border border-[#39FF14]/30 uppercase tracking-wider">
                SIH Innovation #1
              </span>
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Unlike static regex tools, CyberConfig AI dynamically parses previously unseen, proprietary, or legacy network syntaxes into a canonical security model.
            </p>
          </div>
        </div>
      </div>

      {/* Main Interactive Dialect Analyzer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Unseen Syntax Input */}
        <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-6 shadow-2xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-black uppercase tracking-widest text-neutral-300 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-[#39FF14]" />
                Input Unseen / Proprietary Configuration Syntax
              </span>
              <span className="text-[11px] text-neutral-400 font-mono uppercase font-bold">CLI / XML / JSON</span>
            </div>

            <textarea
              value={snippet}
              onChange={(e) => setSnippet(e.target.value)}
              rows={8}
              className="w-full bg-[#0A0A0A] text-neutral-200 font-mono text-xs p-4 rounded-xl border-2 border-[#1A1A1A] focus:outline-none focus:border-[#39FF14] leading-relaxed resize-y"
              placeholder="Paste novel vendor CLI commands or proprietary router statements..."
            />

            {/* Quick Sample Stanzas */}
            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-neutral-400 font-bold uppercase text-[11px]">Try Dialects:</span>
              <button
                onClick={() => setSnippet(`/system access-guard\nenable telnet-service port=2300 permit-ip=any\nset admin-auth type=plaintext secret="NOC_Master_2026"\nset web-portal http-mode=unencrypted port=8080`)}
                className="px-2.5 py-1 rounded-lg bg-[#0A0A0A] hover:bg-neutral-900 border border-[#1A1A1A] text-neutral-300 text-[11px] font-mono font-bold"
              >
                Novel Telecom Gateway
              </button>
              <button
                onClick={() => setSnippet(`system-view\naaa\n local-user superuser password cipher SimplePass@123\n service-type http telnet ssh\nfirewall packet-filter default permit interzone trust untrust`)}
                className="px-2.5 py-1 rounded-lg bg-[#0A0A0A] hover:bg-neutral-900 border border-[#1A1A1A] text-neutral-300 text-[11px] font-mono font-bold"
              >
                Huawei VRP Dialect
              </button>
            </div>
          </div>

          <button
            onClick={handleLearnDialect}
            disabled={isLoading || !snippet.trim()}
            className="w-full py-3 rounded-xl bg-[#39FF14] hover:bg-[#32e010] text-black text-xs font-black uppercase tracking-wider shadow-[0_0_15px_rgba(57,255,20,0.2)] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Analyzing Syntax Tokens with Gemini NLP...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Extract Canonical Semantics & Synthesize Hardening Policy
              </>
            )}
          </button>
        </div>

        {/* Right: AI Semantic Output & Model Mapping */}
        <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-6 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black uppercase tracking-widest text-neutral-300 flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#39FF14]" />
                Canonical Semantic Output & Policy-as-Code
              </span>
              {learnedData && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-[#39FF14]/15 text-[#39FF14] font-mono font-black border border-[#39FF14]/30">
                  Confidence: {((learnedData.confidenceScore || 0.92) * 100).toFixed(0)}%
                </span>
              )}
            </div>

            {learnedData ? (
              <div className="space-y-3 text-xs">
                <div className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400 font-mono text-[11px] uppercase font-bold">Identified Dialect Family:</span>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#39FF14]/15 text-[#39FF14] font-black text-[11px] uppercase border border-[#39FF14]/30">
                      {learnedData.vendorGuess || 'Novel Gateway Dialect'}
                    </span>
                  </div>

                  <div>
                    <span className="text-neutral-400 block text-[11px] uppercase font-bold mt-1">Interpreted Semantic Intent:</span>
                    <p className="text-neutral-200 mt-0.5 leading-relaxed font-sans">
                      {learnedData.interpretedIntent || 'Cleartext remote admin service configured on non-standard port 2300 with plaintext secret.'}
                    </p>
                  </div>
                </div>

                {/* Canonical Category & Risks */}
                <div className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-rose-500/30 space-y-1.5">
                  <span className="text-rose-400 font-black uppercase tracking-wider block text-[11px]">
                    Extracted Vulnerabilities:
                  </span>
                  <ul className="list-disc pl-4 space-y-1 text-neutral-300 text-[11px]">
                    {learnedData.identifiedRisks && Array.isArray(learnedData.identifiedRisks) ? (
                      learnedData.identifiedRisks.map((risk: string, i: number) => (
                        <li key={i}>{risk}</li>
                      ))
                    ) : (
                      <>
                        <li>Cleartext Telnet and HTTP administration listener enabled.</li>
                        <li>Unsalted plaintext credential declaration in memory.</li>
                        <li>Over-permissive pass-all ingress packet filter.</li>
                      </>
                    )}
                  </ul>
                </div>

                {/* Hardened Remediation for this Dialect */}
                <div className="p-3.5 rounded-xl bg-[#0A0A0A] border-2 border-[#39FF14]/40 space-y-1.5">
                  <span className="text-[#39FF14] font-black uppercase tracking-wider block text-[11px] flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#39FF14]" />
                    AI-Synthesized Hardening Command for this Novel Syntax:
                  </span>
                  <pre className="p-2.5 rounded-lg bg-[#141414] font-mono text-[11px] text-[#39FF14] whitespace-pre-wrap border border-[#1A1A1A]">
                    {learnedData.recommendedHardeningPolicy || 
`/system access-guard
disable telnet-service
enable ssh-v2 port=2222 strong-ciphers=aes256-gcm
set admin-auth type=salted-sha256 secret="$6$randomSalt$encrypted..."
set filter-chain ingress action=drop-unmatched`}
                  </pre>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center bg-[#0A0A0A] rounded-xl border-2 border-[#1A1A1A] my-auto">
                <Sparkles className="w-8 h-8 text-[#39FF14] mx-auto mb-2 opacity-80" />
                <h4 className="text-sm font-black uppercase tracking-tight text-neutral-300">Ready to Parse Any Syntax</h4>
                <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                  Click &quot;Extract Canonical Semantics&quot; to test the NLP parser on un-indexed vendor commands.
                </p>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t-2 border-[#1A1A1A] text-[11px] text-neutral-400 flex items-center justify-between font-mono">
            <span>Closed-Loop Model Expansion</span>
            <span className="text-[#39FF14] font-black uppercase">Analyst Verification Active</span>
          </div>
        </div>
      </div>

      {/* Dialect Knowledge Base & Continuous Feedback History */}
      <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-6 shadow-2xl space-y-4">
        <h3 className="text-xs font-black uppercase tracking-widest text-neutral-300 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-[#39FF14]" />
          Continuous Learning Database (Learned Vendor Dialects)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {history.map((rec) => (
            <div key={rec.id} className="p-4 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full bg-[#39FF14]/15 text-[#39FF14] font-black font-mono text-[11px] border border-[#39FF14]/30 uppercase">
                  {rec.vendorGuess}
                </span>
                <span className="text-neutral-500 font-mono text-[11px] uppercase font-bold">{rec.learnedAt}</span>
              </div>
              <p className="text-neutral-300 text-xs font-sans">{rec.interpretedIntent}</p>
              <div className="p-2.5 rounded-lg bg-[#141414] font-mono text-[11px] text-[#39FF14] border border-[#1A1A1A]">
                {rec.recommendedPolicy}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
