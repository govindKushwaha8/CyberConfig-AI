import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Server, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  ArrowUpRight, 
  Search, 
  Filter, 
  Building2, 
  Landmark, 
  Shield, 
  Database, 
  HeartPulse, 
  Terminal,
  Activity,
  CheckCircle2
} from 'lucide-react';
import { INITIAL_FLEET_DEVICES } from '../data/sampleConfigs';
import { FleetDevice, VendorType } from '../types';

interface FleetDashboardProps {
  onSelectDeviceForAudit: (sampleKey: string) => void;
}

export const FleetDashboard: React.FC<FleetDashboardProps> = ({ onSelectDeviceForAudit }) => {
  const [devices, setDevices] = useState<FleetDevice[]>(INITIAL_FLEET_DEVICES);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVendorFilter, setSelectedVendorFilter] = useState<'ALL' | VendorType>('ALL');
  const [selectedSectorFilter, setSelectedSectorFilter] = useState<string>('ALL');

  const filteredDevices = devices.filter(d => {
    const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      d.ip.includes(searchQuery) || 
      d.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesVendor = selectedVendorFilter === 'ALL' || d.vendor === selectedVendorFilter;
    const matchesSector = selectedSectorFilter === 'ALL' || d.sector === selectedSectorFilter;

    return matchesSearch && matchesVendor && matchesSector;
  });

  return (
    <div className="space-y-6">
      {/* Top Prototype Metrics Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-2xl bg-[#141414] border-2 border-[#1A1A1A] shadow-xl">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1 font-mono uppercase font-bold">
            <span>Nodes Scanned</span>
            <Server className="w-4 h-4 text-[#39FF14]" />
          </div>
          <div className="text-3xl font-black text-white tracking-tighter">247</div>
          <p className="text-[11px] font-mono text-[#39FF14] mt-1 flex items-center gap-1.5 uppercase font-bold">
            <span className="w-2 h-2 rounded-full bg-[#39FF14] animate-pulse"></span>
            100% Fleet
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border-2 border-[#1A1A1A] shadow-xl">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1 font-mono uppercase font-bold">
            <span>Compliance</span>
            <Activity className="w-4 h-4 text-[#39FF14]" />
          </div>
          <div className="text-3xl font-black text-[#39FF14] tracking-tighter">78%</div>
          <p className="text-[11px] font-mono text-neutral-400 mt-1 uppercase font-bold">CIS / NIST Baseline</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border-2 border-rose-500/40 shadow-xl">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1 font-mono uppercase font-bold">
            <span>Critical Gaps</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-3xl font-black text-rose-400 tracking-tighter">12</div>
          <p className="text-[11px] font-mono text-rose-300 mt-1 uppercase font-bold">Action Required</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border-2 border-amber-500/40 shadow-xl">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1 font-mono uppercase font-bold">
            <span>High Risk</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-black text-amber-400 tracking-tighter">31</div>
          <p className="text-[11px] font-mono text-amber-300 mt-1 uppercase font-bold">Staged Fixes</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border-2 border-[#1A1A1A] shadow-xl">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1 font-mono uppercase font-bold">
            <span>Medium Risk</span>
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
          </div>
          <div className="text-3xl font-black text-yellow-300 tracking-tighter">47</div>
          <p className="text-[11px] font-mono text-neutral-400 mt-1 uppercase font-bold">Audited Nodes</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#141414] border-2 border-[#1A1A1A] shadow-xl">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1 font-mono uppercase font-bold">
            <span>Audit Velocity</span>
            <CheckCircle2 className="w-4 h-4 text-[#39FF14]" />
          </div>
          <div className="text-3xl font-black text-white tracking-tighter">70%+</div>
          <p className="text-[11px] font-mono text-[#39FF14] mt-1 uppercase font-bold">Time Reduction</p>
        </div>
      </div>

      {/* Real-World Impact Sector Hub */}
      <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-6 shadow-2xl">
        <h3 className="text-xs font-black uppercase tracking-widest text-neutral-400 mb-4 flex items-center gap-2">
          <Building2 className="w-4 h-4 text-[#39FF14]" />
          Multi-Sector Network Security Posture
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          {[
            { name: 'Banks & BFSI', icon: Landmark, count: 64, compliance: '82%', desc: 'Reduce Attack Surface' },
            { name: 'Defense & Strategic', icon: Shield, count: 38, compliance: '68%', desc: 'STIG / NIST Compliance' },
            { name: 'Data Centers', icon: Database, count: 52, compliance: '74%', desc: 'Continuous Assurance' },
            { name: 'Enterprises', icon: Building2, count: 46, compliance: '86%', desc: 'Multi-Vendor Fleet' },
            { name: 'Healthcare', icon: HeartPulse, count: 28, compliance: '71%', desc: 'PHI & Telehealth Security' },
            { name: 'SOC Teams', icon: Terminal, count: 19, compliance: '92%', desc: 'Faster Triage & Fix' },
          ].map((sec, idx) => (
            <div 
              key={idx}
              onClick={() => setSelectedSectorFilter(selectedSectorFilter === sec.name.split(' ')[0] ? 'ALL' : sec.name.split(' ')[0])}
              className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                selectedSectorFilter === sec.name.split(' ')[0]
                  ? 'bg-[#0A0A0A] border-[#39FF14] shadow-[0_0_15px_rgba(57,255,20,0.15)]'
                  : 'bg-[#0A0A0A] border-[#1A1A1A] hover:border-white/20'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <sec.icon className="w-4 h-4 text-[#39FF14]" />
                <span className="font-mono text-[#39FF14] font-black">{sec.compliance}</span>
              </div>
              <div className="font-black uppercase tracking-tight text-white truncate">{sec.name}</div>
              <div className="text-[11px] font-mono text-neutral-400 mt-0.5 uppercase">{sec.count} Nodes</div>
              <div className="text-[10px] text-neutral-500 mt-1 font-medium leading-tight">{sec.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Fleet Inventory Table with 1-Click Launch Auditor */}
      <div className="bg-[#141414] border-2 border-[#1A1A1A] rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-black uppercase tracking-tight text-white flex items-center gap-2">
              <Server className="w-5 h-5 text-[#39FF14]" />
              Enterprise Fleet Nodes ({filteredDevices.length})
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Click &quot;Audit Node&quot; on any node to load its running config into the 6-stage closed-loop auditor.
            </p>
          </div>

          {/* Search & Filter Bar */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search node, IP, vendor..."
                className="pl-10 pr-3.5 py-2 rounded-xl bg-[#0A0A0A] border-2 border-[#1A1A1A] text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-[#39FF14] w-60 font-mono"
              />
            </div>

            {/* Vendor Filter */}
            <select
              value={selectedVendorFilter}
              onChange={(e) => setSelectedVendorFilter(e.target.value as any)}
              className="bg-[#0A0A0A] border-2 border-[#1A1A1A] text-xs text-neutral-200 font-bold uppercase rounded-xl px-3.5 py-2 focus:outline-none focus:border-[#39FF14]"
            >
              <option value="ALL">All Vendors</option>
              <option value="cisco">Cisco IOS-XE</option>
              <option value="juniper">Juniper Junos</option>
              <option value="fortinet">Fortinet FortiOS</option>
              <option value="paloalto">Palo Alto PAN-OS</option>
              <option value="mikrotik">MikroTik RouterOS</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="rounded-xl border-2 border-[#1A1A1A] overflow-x-auto bg-[#0A0A0A]">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-[#141414] text-neutral-400 text-[11px] uppercase tracking-widest font-black border-b-2 border-[#1A1A1A]">
              <tr>
                <th className="py-3.5 px-4">Node / Hostname</th>
                <th className="py-3.5 px-4">Vendor & Model</th>
                <th className="py-3.5 px-4">Sector & Region</th>
                <th className="py-3.5 px-4 text-center">Compliance</th>
                <th className="py-3.5 px-4 text-center">Findings</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] font-mono">
              {filteredDevices.map((dev) => (
                <tr key={dev.id} className="hover:bg-[#141414] transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-white font-sans text-sm">{dev.name}</div>
                    <span className="text-[11px] text-neutral-400">{dev.ip}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#39FF14]/15 text-[#39FF14] border border-[#39FF14]/30 uppercase inline-block mb-1">
                      {dev.vendor}
                    </span>
                    <div className="text-[11px] text-neutral-400 font-sans">{dev.model}</div>
                  </td>
                  <td className="py-3.5 px-4 font-sans">
                    <div className="text-white font-bold text-xs">{dev.sector}</div>
                    <span className="text-[11px] text-neutral-400">{dev.location}</span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className={`text-lg font-black tracking-tight ${dev.complianceScore >= 80 ? 'text-[#39FF14]' : 'text-rose-400'}`}>
                      {dev.complianceScore}%
                    </span>
                    <span className="block text-[10px] text-neutral-500 font-bold uppercase">{dev.status}</span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5 text-[11px]">
                      <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-black border border-rose-500/40" title="Critical Issues">
                        {dev.criticalIssues}C
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-black border border-amber-500/40" title="High Issues">
                        {dev.highIssues}H
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-300 font-black border border-yellow-500/40" title="Medium Issues">
                        {dev.mediumIssues}M
                      </span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right font-sans">
                    <button
                      onClick={() => onSelectDeviceForAudit(dev.sampleConfigKey)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#39FF14] hover:bg-[#32e010] text-black text-xs font-black uppercase tracking-wider shadow-[0_0_10px_rgba(57,255,20,0.2)] transition-all"
                    >
                      <span>Audit Node</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
