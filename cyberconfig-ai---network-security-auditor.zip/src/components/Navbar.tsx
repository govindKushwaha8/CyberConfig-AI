import React from 'react';
import { 
  Shield, 
  Terminal, 
  LayoutDashboard, 
  Cpu, 
  MessageSquareCode, 
  FileCheck2, 
  Presentation,
  Sparkles,
  Award
} from 'lucide-react';

interface NavbarProps {
  activeTab: 'auditor' | 'fleet' | 'dialect' | 'copilot' | 'report' | 'pitch';
  setActiveTab: (tab: 'auditor' | 'fleet' | 'dialect' | 'copilot' | 'report' | 'pitch') => void;
  aiStatus: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, aiStatus }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0A0A0A] border-b-2 border-[#1A1A1A] text-white shadow-2xl">
      {/* SIH Top Identity Bar */}
      <div className="bg-[#141414] border-b border-white/10 px-4 py-2 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-[#39FF14] font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-[#39FF14]" />
              SIH 2026 / PRE-QUALIFIER
            </span>
            <span className="text-neutral-600 hidden sm:inline">/</span>
            <span className="text-neutral-400 font-mono text-[11px] uppercase tracking-wider hidden sm:inline">
              PS ID: <strong className="text-white font-black">SIH26155</strong>
            </span>
            <span className="text-neutral-600 hidden md:inline">/</span>
            <span className="text-neutral-400 font-mono text-[11px] uppercase tracking-wider hidden md:inline">
              Team: <strong className="text-[#39FF14] font-black">Cyber Shield</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#1A1A1A] border border-white/15 text-[11px] font-mono uppercase tracking-wider">
              <span className={`w-2 h-2 rounded-full ${aiStatus ? 'bg-[#39FF14] shadow-[0_0_8px_#39FF14] animate-pulse' : 'bg-[#39FF14]'}`}></span>
              <span className="text-neutral-400">Gemini 3.7: <span className="text-[#39FF14] font-black">ONLINE</span></span>
            </div>
            <span className="text-neutral-500 font-mono text-[10px] uppercase tracking-widest hidden lg:inline">
              Nodes: <span className="text-white font-bold">247</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main App Navigation */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand */}
        <div 
          onClick={() => setActiveTab('auditor')}
          className="flex items-center gap-3.5 cursor-pointer group"
        >
          <div className="w-11 h-11 rounded-xl bg-[#141414] border-2 border-[#39FF14]/60 flex items-center justify-center shadow-[0_0_15px_rgba(57,255,20,0.2)] group-hover:border-[#39FF14] group-hover:scale-105 transition-all">
            <Shield className="w-6 h-6 text-[#39FF14]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tighter italic uppercase text-white flex items-center gap-1.5">
                CYBERCONFIG<span className="text-[#39FF14]">.AI</span>
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#39FF14]/15 text-[#39FF14] border border-[#39FF14]/40">
                v2.6 MVP
              </span>
            </div>
            <p className="text-[10px] font-mono tracking-widest uppercase text-neutral-400 leading-none mt-0.5">
              Multi-Vendor Network Security Auditor
            </p>
          </div>
        </div>

        {/* Tab Buttons */}
        <nav className="flex items-center gap-1.5 overflow-x-auto py-1">
          <button
            id="nav-auditor-btn"
            onClick={() => setActiveTab('auditor')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
              activeTab === 'auditor'
                ? 'bg-[#39FF14] text-black shadow-[0_0_15px_rgba(57,255,20,0.3)]'
                : 'text-neutral-300 hover:text-white hover:bg-[#1A1A1A] border border-transparent hover:border-white/10'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Auditor</span>
          </button>

          <button
            id="nav-fleet-btn"
            onClick={() => setActiveTab('fleet')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
              activeTab === 'fleet'
                ? 'bg-[#39FF14] text-black shadow-[0_0_15px_rgba(57,255,20,0.3)]'
                : 'text-neutral-300 hover:text-white hover:bg-[#1A1A1A] border border-transparent hover:border-white/10'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Fleet</span>
            <span className={`ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${
              activeTab === 'fleet' ? 'bg-black text-[#39FF14]' : 'bg-[#1A1A1A] text-neutral-400'
            }`}>247</span>
          </button>

          <button
            id="nav-dialect-btn"
            onClick={() => setActiveTab('dialect')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
              activeTab === 'dialect'
                ? 'bg-[#39FF14] text-black shadow-[0_0_15px_rgba(57,255,20,0.3)]'
                : 'text-neutral-300 hover:text-white hover:bg-[#1A1A1A] border border-transparent hover:border-white/10'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>NLP Parser</span>
          </button>

          <button
            id="nav-copilot-btn"
            onClick={() => setActiveTab('copilot')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
              activeTab === 'copilot'
                ? 'bg-[#39FF14] text-black shadow-[0_0_15px_rgba(57,255,20,0.3)]'
                : 'text-neutral-300 hover:text-white hover:bg-[#1A1A1A] border border-transparent hover:border-white/10'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Copilot</span>
          </button>

          <button
            id="nav-report-btn"
            onClick={() => setActiveTab('report')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
              activeTab === 'report'
                ? 'bg-[#39FF14] text-black shadow-[0_0_15px_rgba(57,255,20,0.3)]'
                : 'text-neutral-300 hover:text-white hover:bg-[#1A1A1A] border border-transparent hover:border-white/10'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Evidence</span>
          </button>

          <button
            id="nav-pitch-btn"
            onClick={() => setActiveTab('pitch')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
              activeTab === 'pitch'
                ? 'bg-white text-black shadow-lg shadow-white/20'
                : 'text-neutral-400 hover:text-white hover:bg-[#1A1A1A] border border-white/20'
            }`}
          >
            <Presentation className="w-4 h-4 text-[#39FF14]" />
            <span>SIH Deck</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
