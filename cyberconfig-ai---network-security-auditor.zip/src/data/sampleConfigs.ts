import { FleetDevice, VendorType } from '../types';

export interface SampleConfigItem {
  id: string;
  name: string;
  vendor: VendorType;
  deviceModel: string;
  sector: 'Banking' | 'Defense' | 'Enterprise' | 'Data Center' | 'Healthcare' | 'Government';
  description: string;
  rawConfig: string;
}

export const SAMPLE_CONFIGS: Record<string, SampleConfigItem> = {
  cisco_core_switch: {
    id: 'cisco_core_switch',
    name: 'MUM-CORE-SW-01 (Cisco Catalyst 9300)',
    vendor: 'cisco',
    deviceModel: 'Catalyst 9300-48UXM (IOS-XE 17.9)',
    sector: 'Banking',
    description: 'Core Distribution Switch for Mumbai Financial Hub. Contains active Telnet, weak SNMP v2c community, and over-permissive management ACL.',
    rawConfig: `! Cisco IOS-XE Software, Catalyst L3 Switch
version 17.9
service timestamps debug datetime msec
service timestamps log datetime msec
no service password-encryption
!
hostname MUM-CORE-SW01
!
enable password cisco123
!
username admin privilege 15 secret 5 $1$mERr$hp5p4y...
username backup_auditor privilege 5 password auditpass
!
ip domain-name corp.bank.in
ip name-server 10.0.0.53
!
ip http server
no ip http secure-server
!
ip ssh version 1
!
snmp-server community public RO
snmp-server community private RW
snmp-server enable traps
!
ntp server 10.10.10.1
! (Missing: ntp authenticate, ntp trusted-key)
!
interface GigabitEthernet1/0/1
 description UPLINK-TO-INTERNET-EDGE
 ip address 192.168.100.2 255.255.255.252
 ip access-group 101 in
!
interface GigabitEthernet1/0/2
 description INTERNAL-LAN-VLAN10
 ip address 10.10.1.1 255.255.255.0
!
access-list 101 permit tcp any any eq 23
access-list 101 permit ip any any
!
banner motd ^C
Welcome to Mumbai Banking Switch - Authorized Access Only
^C
!
line con 0
 exec-timeout 0 0
 logging synchronous
line vty 0 4
 transport input telnet ssh
 login local
 exec-timeout 0 0
line vty 5 15
 transport input telnet
 login local
!
end`
  },

  juniper_edge_router: {
    id: 'juniper_edge_router',
    name: 'DEL-DEF-GW-02 (Juniper SRX-345)',
    vendor: 'juniper',
    deviceModel: 'SRX345 Services Gateway (Junos 21.4R3)',
    sector: 'Defense',
    description: 'Perimeter Gateway for Strategic Defense Infrastructure. Contains cleartext telnet service, SSH root login enabled, and missing audit syslog forwarding.',
    rawConfig: `## Junos OS Configuration for Defense Perimeter Gateway
version 21.4R3.5;
system {
    host-name DEL-DEF-GW02;
    domain-name mil.nic.in;
    root-authentication {
        plain-text-password-value "Defence@2024!";
    }
    services {
        ssh {
            root-login allow;
            protocol-version v1;
            ciphers [ "3des-cbc" "aes128-cbc" ];
        }
        telnet;
        web-management {
            http {
                port 80;
                interface ge-0/0/0.0;
            }
            https {
                port 443;
                system-generated-certificate;
            }
        }
    }
    syslog {
        user * {
            any emergency;
        }
        file messages {
            any notice;
            authorization info;
        }
    }
    ntp {
        server 192.168.20.10;
    }
}
snmp {
    community public {
        authorization read-only;
    }
    community secret_netops {
        authorization read-write;
    }
}
security {
    zones {
        security-zone untrust {
            interfaces {
                ge-0/0/0.0 {
                    host-inbound-traffic {
                        system-services {
                            all;
                        }
                    }
                }
            }
        }
    }
    policies {
        from-zone untrust to-zone trust {
            policy allow-all-traffic {
                match {
                    source-address any;
                    destination-address any;
                    application any;
                }
                then {
                    permit;
                }
            }
        }
    }
}`
  },

  fortinet_firewall: {
    id: 'fortinet_firewall',
    name: 'BLR-DC-FW-01 (FortiGate 100F)',
    vendor: 'fortinet',
    deviceModel: 'FortiGate 100F (FortiOS 7.2.4)',
    sector: 'Data Center',
    description: 'Next-Gen Firewall Protecting Cloud Infrastructure. Has HTTP admin web UI, weak SSL-VPN TLS ciphers, and uninspected permit rules.',
    rawConfig: `config system global
    set hostname "BLR-DC-FW01"
    set admintimeout 480
    set admin-sport 443
    set admin-port 80
    set admin-ssh-port 22
    set admin-telnet-port 23
    set admin-lockout-threshold 0
    set admin-scp enable
    set strong-crypto disable
    set ssl-min-proto-version tls1-1
end

config system admin
    edit "admin"
        set accprofile "super_admin"
        set vdom "root"
        set password ENC AQAAxyz...
    next
end

config system interface
    edit "wan1"
        set vdom "root"
        set ip 203.0.113.10 255.255.255.0
        set allowaccess ping https http ssh telnet fgfm
        set type physical
    next
end

config firewall policy
    edit 1
        set name "Allow-All-Inbound"
        set srcintf "wan1"
        set dstintf "internal"
        set srcaddr "all"
        set dstaddr "all"
        set action accept
        set schedule "always"
        set service "ALL"
        set utm-status disable
        set logtraffic all
    next
end

config log syslogd setting
    set status disable
end

config system snmp community
    edit 1
        set name "public"
        config hosts
            edit 1
                set ip 0.0.0.0 0.0.0.0
            next
        end
    next
end`
  },

  paloalto_ngfw: {
    id: 'paloalto_ngfw',
    name: 'HYD-HEALTH-FW-01 (Palo Alto PA-3220)',
    vendor: 'paloalto',
    deviceModel: 'Palo Alto PA-3220 (PAN-OS 10.2)',
    sector: 'Healthcare',
    description: 'Hospital Patient Data Center Firewall. Permits Telnet/HTTP on management profile, lacks decryption policy, wildcard admin access.',
    rawConfig: `set deviceconfig system hostname HYD-HEALTH-FW01
set deviceconfig system ip-address 10.50.0.1 netmask 255.255.255.0 default-gateway 10.50.0.254
set deviceconfig system dns-setting servers primary 8.8.8.8

set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" http yes
set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" https yes
set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" telnet yes
set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" ssh yes
set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" ping yes

set network interface ethernet ethernet1/1 layer3 ip 10.50.0.1/24
set network interface ethernet ethernet1/1 layer3 interface-management-profile "MGMT-PERMISSIVE"

set rulebase security rules "Permit-All-Outbound" from any to any source any destination any service any application any action allow
set rulebase security rules "Inbound-Web" from untrust to trust source any destination 10.50.10.10 service application-default action allow log-end yes

set shared authentication-profile "LocalAuth" method local-database
set mgt-config users admin password-hash $1$adminhash...
set mgt-config users admin permissions role-based superuser yes

set deviceconfig system ntp-servers primary-ntp-server 10.50.0.250
set deviceconfig system login-banner ""
set deviceconfig system syslog-profile "CENTRAL-LOGS" server 10.50.0.99 transport UDP port 514`
  },

  mikrotik_unknown_syntax: {
    id: 'mikrotik_unknown_syntax',
    name: 'PUN-ENT-RT-01 (MikroTik RouterOS / Novel Dialect)',
    vendor: 'mikrotik',
    deviceModel: 'Cloud Core Router CCR2004 (RouterOS v7.11)',
    sector: 'Enterprise',
    description: 'Unseen/Novel Vendor Dialect testing CyberConfig AI\'s Self-Learning NLP Parser engine for automated canonical mapping.',
    rawConfig: `# RouterOS v7.11 Configuration Export
# Model: CCR2004-1G-12S+2XS
/system identity
set name=PUN-ENT-RT01

/ip service
set telnet disabled=no port=23 address=0.0.0.0/0
set ftp disabled=no port=21
set www disabled=no port=80
set ssh disabled=no port=22 strong-crypto=no
set www-ssl disabled=yes port=443
set api disabled=no port=8728
set winbox disabled=no port=8291

/user
add name=admin group=full password="plainAdminPassword!"
add name=operator group=read password="operatorPass"

/snmp
set enabled=yes contact="noc@enterprise.in" location="Pune HQ"
/snmp community
add name=public read-access=yes write-access=yes addresses=0.0.0.0/0

/ip firewall filter
add chain=input action=accept protocol=tcp dst-port=22,23,80 comment="Allow all management from anywhere"
add chain=forward action=accept comment="Forward everything unconditionally"

/system logging
add topics=critical action=memory
add topics=error action=memory
# Remote syslog server omitted

/system ntp client
set enabled=yes
set servers=time.google.com`
  }
};

export const INITIAL_FLEET_DEVICES: FleetDevice[] = [
  {
    id: 'dev-001',
    name: 'MUM-CORE-SW-01',
    ip: '10.14.0.1',
    vendor: 'cisco',
    model: 'Catalyst 9300-48UXM',
    location: 'Mumbai DC-1',
    sector: 'Banking',
    lastScanned: '12 mins ago',
    complianceScore: 48,
    criticalIssues: 4,
    highIssues: 5,
    mediumIssues: 3,
    lowIssues: 1,
    status: 'Non-Compliant',
    sampleConfigKey: 'cisco_core_switch'
  },
  {
    id: 'dev-002',
    name: 'DEL-DEF-GW-02',
    ip: '10.22.1.254',
    vendor: 'juniper',
    model: 'SRX345 Services Gateway',
    location: 'New Delhi HQ',
    sector: 'Defense',
    lastScanned: '28 mins ago',
    complianceScore: 54,
    criticalIssues: 3,
    highIssues: 4,
    mediumIssues: 4,
    lowIssues: 2,
    status: 'Non-Compliant',
    sampleConfigKey: 'juniper_edge_router'
  },
  {
    id: 'dev-003',
    name: 'BLR-DC-FW-01',
    ip: '172.16.100.1',
    vendor: 'fortinet',
    model: 'FortiGate 100F',
    location: 'Bengaluru Cloud Center',
    sector: 'Data Center',
    lastScanned: '45 mins ago',
    complianceScore: 42,
    criticalIssues: 5,
    highIssues: 6,
    mediumIssues: 3,
    lowIssues: 1,
    status: 'Non-Compliant',
    sampleConfigKey: 'fortinet_firewall'
  },
  {
    id: 'dev-004',
    name: 'HYD-HEALTH-FW-01',
    ip: '10.50.0.1',
    vendor: 'paloalto',
    model: 'PA-3220 NGFW',
    location: 'Hyderabad Health Pod',
    sector: 'Healthcare',
    lastScanned: '1 hour ago',
    complianceScore: 58,
    criticalIssues: 3,
    highIssues: 4,
    mediumIssues: 2,
    lowIssues: 2,
    status: 'At Risk',
    sampleConfigKey: 'paloalto_ngfw'
  },
  {
    id: 'dev-005',
    name: 'PUN-ENT-RT-01',
    ip: '192.168.1.1',
    vendor: 'mikrotik',
    model: 'RouterBOARD CCR2004',
    location: 'Pune Tech Park',
    sector: 'Enterprise',
    lastScanned: '2 hours ago',
    complianceScore: 36,
    criticalIssues: 6,
    highIssues: 5,
    mediumIssues: 4,
    lowIssues: 2,
    status: 'Non-Compliant',
    sampleConfigKey: 'mikrotik_unknown_syntax'
  },
  {
    id: 'dev-006',
    name: 'KOL-BANK-EDGE-01',
    ip: '10.88.2.1',
    vendor: 'cisco',
    model: 'ASR 1001-X WAN Router',
    location: 'Kolkata Regional Branch',
    sector: 'Banking',
    lastScanned: '3 hours ago',
    complianceScore: 82,
    criticalIssues: 1,
    highIssues: 2,
    mediumIssues: 4,
    lowIssues: 3,
    status: 'Compliant',
    sampleConfigKey: 'cisco_core_switch'
  },
  {
    id: 'dev-007',
    name: 'CHN-PORT-SEC-01',
    ip: '10.90.10.254',
    vendor: 'fortinet',
    model: 'FortiGate 200F',
    location: 'Chennai Port Authority',
    sector: 'Government',
    lastScanned: '4 hours ago',
    complianceScore: 78,
    criticalIssues: 1,
    highIssues: 3,
    mediumIssues: 3,
    lowIssues: 2,
    status: 'Compliant',
    sampleConfigKey: 'fortinet_firewall'
  }
];
