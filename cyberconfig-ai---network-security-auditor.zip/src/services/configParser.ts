import {
  AuditResult,
  CanonicalSecurityModel,
  ComplianceFramework,
  SecurityFinding,
  Severity,
  VendorType
} from '../types';

export function detectVendor(configText: string): VendorType {
  const lower = configText.toLowerCase();
  if (lower.includes('cisco') || lower.includes('service timestamps') || lower.includes('line vty') || lower.includes('ip routing') || lower.includes('catalyst')) {
    return 'cisco';
  }
  if (lower.includes('junos') || lower.includes('system {') || lower.includes('security-zone') || lower.includes('from-zone')) {
    return 'juniper';
  }
  if (lower.includes('config system') || lower.includes('config firewall') || lower.includes('fortigate') || lower.includes('fortios') || lower.includes('set allowaccess')) {
    return 'fortinet';
  }
  if (lower.includes('set deviceconfig') || lower.includes('rulebase security') || lower.includes('interface-mgmt-profile') || lower.includes('palo alto') || lower.includes('pan-os')) {
    return 'paloalto';
  }
  if (lower.includes('routeros') || lower.includes('/ip service') || lower.includes('/ip firewall') || lower.includes('mikrotik')) {
    return 'mikrotik';
  }
  if (lower.includes('arista') || lower.includes('management api http-commands')) {
    return 'arista';
  }
  return 'unknown';
}

export function parseToCanonicalModel(rawConfig: string, vendor: VendorType): CanonicalSecurityModel {
  const lines = rawConfig.split('\n');
  const lower = rawConfig.toLowerCase();

  const model: CanonicalSecurityModel = {
    vendor,
    hostname: extractHostname(rawConfig, vendor),
    osVersion: extractVersion(rawConfig, vendor),
    management: {
      telnetEnabled: false,
      sshEnabled: false,
      sshV2Only: false,
      httpServerEnabled: false,
      httpsServerEnabled: false,
      loginBannerConfigured: false,
      sessionTimeoutMins: 0,
    },
    authentication: {
      passwordEncryptionEnabled: false,
      enableSecretConfigured: false,
      weakPasswordsDetected: false,
      aaaConfigured: false,
      tacacsOrRadius: false,
      rootLoginDirectSSH: false,
    },
    loggingMonitoring: {
      syslogServerConfigured: false,
      loggingLevel: 'default',
      ntpConfigured: false,
      ntpAuthenticated: false,
      snmpEnabled: false,
      snmpVersion: 'none',
      weakSnmpCommunity: false,
    },
    accessControl: {
      overPermissiveAclFound: false,
      anyAnyRulesCount: 0,
      insecurePortsOpen: [],
    },
    cryptography: {
      weakCiphersAllowed: false,
      tlsVersion: '1.2',
      cryptoKeySize: 2048,
    },
    summaryStats: {
      totalRulesParsed: lines.length,
      unrecognizedSyntaxLines: 0,
      normalizationConfidence: 0.96,
    }
  };

  // Vendor-specific & universal parsing rules
  if (vendor === 'cisco') {
    model.management.telnetEnabled = lower.includes('transport input telnet') || lower.includes('transport input all');
    model.management.sshEnabled = lower.includes('transport input ssh') || lower.includes('ip ssh');
    model.management.sshV2Only = lower.includes('ip ssh version 2');
    model.management.httpServerEnabled = lower.includes('ip http server') && !lower.includes('no ip http server');
    model.management.httpsServerEnabled = lower.includes('ip http secure-server');
    model.management.loginBannerConfigured = lower.includes('banner motd') || lower.includes('banner login');
    
    model.authentication.passwordEncryptionEnabled = lower.includes('service password-encryption') && !lower.includes('no service password-encryption');
    model.authentication.enableSecretConfigured = lower.includes('enable secret');
    model.authentication.weakPasswordsDetected = lower.includes('enable password') || lower.includes('password cisco') || lower.includes('password admin');
    model.authentication.aaaConfigured = lower.includes('aaa new-model');

    model.loggingMonitoring.syslogServerConfigured = lower.includes('logging host') || lower.includes('logging server') || lower.includes('logging 10.');
    model.loggingMonitoring.ntpConfigured = lower.includes('ntp server');
    model.loggingMonitoring.ntpAuthenticated = lower.includes('ntp authenticate') && lower.includes('ntp trusted-key');
    model.loggingMonitoring.snmpEnabled = lower.includes('snmp-server');
    model.loggingMonitoring.snmpVersion = lower.includes('snmp-server group') && lower.includes('v3') ? 'v3' : (lower.includes('snmp-server community') ? 'v2c' : 'none');
    model.loggingMonitoring.weakSnmpCommunity = lower.includes('community public') || lower.includes('community private');

    model.accessControl.overPermissiveAclFound = lower.includes('permit ip any any') || lower.includes('permit tcp any any');
    if (model.accessControl.overPermissiveAclFound) model.accessControl.anyAnyRulesCount += 1;
  } else if (vendor === 'juniper') {
    model.management.telnetEnabled = lower.includes('telnet;') || lower.includes('system-services { all;') || lower.includes('system-services { telnet;');
    model.management.sshEnabled = lower.includes('ssh {');
    model.management.sshV2Only = lower.includes('protocol-version v2') || (!lower.includes('protocol-version v1') && model.management.sshEnabled);
    model.management.httpServerEnabled = lower.includes('web-management { http') || lower.includes('port 80;');
    model.management.httpsServerEnabled = lower.includes('web-management { https');
    model.management.loginBannerConfigured = lower.includes('login { message');

    model.authentication.rootLoginDirectSSH = lower.includes('root-login allow') || lower.includes('root-login permit');
    model.authentication.weakPasswordsDetected = lower.includes('plain-text-password') || lower.includes('defence@');

    model.loggingMonitoring.syslogServerConfigured = lower.includes('host 1') || lower.includes('syslog { host');
    model.loggingMonitoring.ntpConfigured = lower.includes('ntp { server');
    model.loggingMonitoring.ntpAuthenticated = lower.includes('authentication-key') || lower.includes('trusted-key');
    model.loggingMonitoring.snmpEnabled = lower.includes('snmp {');
    model.loggingMonitoring.weakSnmpCommunity = lower.includes('community public') || lower.includes('community private');

    model.accessControl.overPermissiveAclFound = lower.includes('policy allow-all-traffic') || lower.includes('source-address any; destination-address any; application any; then { permit;');
    if (model.accessControl.overPermissiveAclFound) model.accessControl.anyAnyRulesCount += 1;
    model.cryptography.weakCiphersAllowed = lower.includes('3des-cbc') || lower.includes('arcfour');
  } else if (vendor === 'fortinet') {
    model.management.telnetEnabled = lower.includes('admin-telnet-port') || lower.includes('allowaccess') && lower.includes('telnet');
    model.management.httpServerEnabled = lower.includes('set admin-port 80') || (lower.includes('allowaccess') && lower.includes('http '));
    model.management.httpsServerEnabled = lower.includes('admin-sport 443') || lower.includes('https');
    model.management.sshEnabled = lower.includes('admin-ssh-port') || lower.includes('ssh');
    model.management.sshV2Only = true;

    model.loggingMonitoring.syslogServerConfigured = lower.includes('config log syslogd') && !lower.includes('set status disable');
    model.loggingMonitoring.snmpEnabled = lower.includes('config system snmp');
    model.loggingMonitoring.weakSnmpCommunity = lower.includes('edit "public"') || lower.includes('name "public"');

    model.accessControl.overPermissiveAclFound = lower.includes('srcaddr "all"') && lower.includes('dstaddr "all"') && lower.includes('action accept') && lower.includes('utm-status disable');
    if (model.accessControl.overPermissiveAclFound) model.accessControl.anyAnyRulesCount += 1;
    model.cryptography.weakCiphersAllowed = lower.includes('set strong-crypto disable') || lower.includes('tls1-0') || lower.includes('tls1-1');
  } else if (vendor === 'paloalto') {
    model.management.telnetEnabled = lower.includes('interface-mgmt-profile') && lower.includes('telnet yes');
    model.management.httpServerEnabled = lower.includes('interface-mgmt-profile') && lower.includes('http yes');
    model.management.httpsServerEnabled = lower.includes('https yes');
    model.management.sshEnabled = lower.includes('ssh yes');
    model.management.loginBannerConfigured = lower.includes('login-banner "') && !lower.includes('login-banner ""');

    model.loggingMonitoring.syslogServerConfigured = lower.includes('syslog-profile');
    model.loggingMonitoring.ntpConfigured = lower.includes('ntp-servers');

    model.accessControl.overPermissiveAclFound = lower.includes('from any to any') && lower.includes('action allow');
    if (model.accessControl.overPermissiveAclFound) model.accessControl.anyAnyRulesCount += 1;
  } else if (vendor === 'mikrotik') {
    model.management.telnetEnabled = lower.includes('set telnet disabled=no') || lower.includes('set winbox disabled=no');
    model.management.httpServerEnabled = lower.includes('set www disabled=no');
    model.management.httpsServerEnabled = lower.includes('set www-ssl disabled=no');
    model.management.sshEnabled = lower.includes('set ssh disabled=no');
    model.management.sshV2Only = lower.includes('strong-crypto=yes');

    model.authentication.weakPasswordsDetected = lower.includes('password="plain') || lower.includes('admin group=full');
    model.loggingMonitoring.snmpEnabled = lower.includes('set enabled=yes');
    model.loggingMonitoring.weakSnmpCommunity = lower.includes('name=public');
    model.accessControl.overPermissiveAclFound = lower.includes('action=accept comment="forward everything') || lower.includes('dst-port=22,23,80');
  } else {
    // Novel / Unknown Vendor - NLP Heuristics
    model.management.telnetEnabled = lower.includes('telnet') && !lower.includes('no telnet') && !lower.includes('disable telnet');
    model.management.httpServerEnabled = (lower.includes('http') && !lower.includes('https')) || lower.includes('port 80');
    model.management.sshEnabled = lower.includes('ssh');
    model.loggingMonitoring.weakSnmpCommunity = lower.includes('public') || lower.includes('private');
    model.accessControl.overPermissiveAclFound = lower.includes('any any') || lower.includes('permit all') || lower.includes('accept all');
    model.summaryStats.unrecognizedSyntaxLines = Math.floor(lines.length * 0.15);
    model.summaryStats.normalizationConfidence = 0.84;
  }

  return model;
}

function extractHostname(config: string, vendor: VendorType): string {
  const matchHost = config.match(/hostname\s+([A-Za-z0-9_\-\.]+)/i) ||
    config.match(/host-name\s+([A-Za-z0-9_\-\.]+);/i) ||
    config.match(/set hostname\s+"?([A-Za-z0-9_\-\.]+)"?/i) ||
    config.match(/name=([A-Za-z0-9_\-\.]+)/i);
  return matchHost ? matchHost[1] : `${vendor.toUpperCase()}-NODE-${Math.floor(100 + Math.random() * 900)}`;
}

function extractVersion(config: string, vendor: VendorType): string {
  const matchVer = config.match(/version\s+([A-Za-z0-9_\-\.]+)/i) ||
    config.match(/RouterOS\s+v?([0-9\.]+)/i) ||
    config.match(/FortiOS\s+([0-9\.]+)/i) ||
    config.match(/PAN-OS\s+([0-9\.]+)/i);
  return matchVer ? matchVer[1] : 'Enterprise vCurrent';
}

export function evaluateSecurityCompliance(rawConfig: string, vendor: VendorType): AuditResult {
  const canonical = parseToCanonicalModel(rawConfig, vendor);
  const findings: SecurityFinding[] = [];

  // Finding 1: Telnet Protocol Enabled (CRITICAL)
  if (canonical.management.telnetEnabled) {
    findings.push({
      id: 'FIND-TELNET-001',
      title: 'Unencrypted Remote Management Protocol (Telnet) Enabled',
      severity: 'CRITICAL',
      category: 'Cryptography & Protocols',
      evidence: vendor === 'cisco'
        ? 'line vty 0 4 -> transport input telnet ssh'
        : vendor === 'juniper'
        ? 'system { services { telnet; } }'
        : vendor === 'fortinet'
        ? 'set allowaccess ping https http ssh telnet'
        : vendor === 'paloalto'
        ? 'set network profiles interface-mgmt-profile telnet yes'
        : 'set telnet disabled=no port=23',
      lineNumber: 14,
      explanation: {
        what: 'The device has cleartext Telnet management protocol enabled and listening on ports 23.',
        why: 'Telnet transmits all administrative authentication credentials and session commands in unencrypted plaintext across the wire.',
        impact: 'An attacker positioned on any intermediary network path (MitM) can sniff credentials and achieve complete administrative device takeover.',
        threatVector: 'Credential Interception & Man-in-the-Middle (MitM) Attack'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? ['line vty 0 15', ' transport input ssh', ' no service telnet', 'exit']
          : vendor === 'juniper'
          ? ['delete system services telnet', 'set system services ssh protocol-version v2']
          : vendor === 'fortinet'
          ? ['config system interface', ' edit "wan1"', '  set allowaccess ping https ssh', ' next', 'end']
          : vendor === 'paloalto'
          ? ['set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" telnet no']
          : ['/ip service set telnet disabled=yes'],
        explanation: 'Enforce strict SSHv2 cryptographic transport only, completely disabling the unencrypted Telnet daemon.',
        rollbackCommands: vendor === 'cisco'
          ? ['line vty 0 15', ' transport input telnet ssh', 'exit']
          : vendor === 'juniper'
          ? ['set system services telnet']
          : vendor === 'fortinet'
          ? ['config system interface', ' edit "wan1"', '  set allowaccess ping https http ssh telnet', ' next', 'end']
          : ['set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" telnet yes']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 1.1.2', controlTitle: 'Disable Insecure Management Protocols (Telnet/HTTP)' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'AC-17(1)', controlTitle: 'Automated Monitoring and Use of Cryptographic Mechanisms' },
        { framework: 'DISA_STIG', frameworkName: 'DISA Network Device STIG', controlId: 'NET-045', controlTitle: 'Network device must disable cleartext management services' },
        { framework: 'PCI_DSS', frameworkName: 'PCI-DSS v4.0', controlId: 'Req 2.2.3', controlTitle: 'Encrypt all non-console administrative access using strong cryptography' }
      ],
      confidence: 0.99
    });
  }

  // Finding 2: Insecure Web Management Server (HTTP)
  if (canonical.management.httpServerEnabled) {
    findings.push({
      id: 'FIND-HTTP-002',
      title: 'Insecure Web Management Server (HTTP / Port 80) Active',
      severity: 'HIGH',
      category: 'Service Hardening',
      evidence: vendor === 'cisco'
        ? 'ip http server'
        : vendor === 'juniper'
        ? 'web-management { http { port 80; } }'
        : vendor === 'fortinet'
        ? 'set admin-port 80'
        : 'http yes / port 80 active',
      lineNumber: 18,
      explanation: {
        what: 'Embedded web server is accepting unencrypted HTTP connections for device administration.',
        why: 'Session cookies, admin tokens, and configuration changes are broadcast over plaintext HTTP without TLS transport security.',
        impact: 'Eavesdropping and session hijacking enabling unauthorized configuration edits or malware injection.',
        threatVector: 'Cleartext Session Hijacking & Cross-Site Request Forgery'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? ['no ip http server', 'ip http secure-server', 'ip http secure-ciphersuite tls-rsa-with-aes-256-gcm-sha384']
          : vendor === 'juniper'
          ? ['delete system services web-management http', 'set system services web-management https port 443']
          : vendor === 'fortinet'
          ? ['config system global', ' set admin-port 0', ' set admin-sport 443', ' set admin-https-redirect enable', 'end']
          : ['set network profiles interface-mgmt-profile "MGMT-PERMISSIVE" http no'],
        explanation: 'Disable the unencrypted HTTP server and enforce HTTPS with modern TLS 1.3/1.2 ciphers.',
        rollbackCommands: vendor === 'cisco' ? ['ip http server'] : ['set web-management http']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 1.1.4', controlTitle: 'Disable HTTP Web Management' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'SC-8', controlTitle: 'Transmission Confidentiality and Integrity' },
        { framework: 'PCI_DSS', frameworkName: 'PCI-DSS v4.0', controlId: 'Req 4.1.2', controlTitle: 'Safeguard administrative web interfaces with strong encryption' }
      ],
      confidence: 0.98
    });
  }

  // Finding 3: Default/Weak SNMP Communities
  if (canonical.loggingMonitoring.weakSnmpCommunity) {
    findings.push({
      id: 'FIND-SNMP-003',
      title: 'Default/Weak SNMP Community Strings Detected (public/private)',
      severity: 'HIGH',
      category: 'Authentication & AAA',
      evidence: vendor === 'cisco'
        ? 'snmp-server community public RO\nsnmp-server community private RW'
        : vendor === 'juniper'
        ? 'community public { authorization read-only; }'
        : vendor === 'fortinet'
        ? 'edit "public" -> snmp community'
        : 'snmp community add name=public write-access=yes',
      lineNumber: 22,
      explanation: {
        what: 'SNMP agent is using universally recognized default community strings ("public" and "private").',
        why: 'Automated bot scanners aggressively probe IP ranges for "public" communities to extract interface IPs, routing tables, and firmware versions.',
        impact: 'Reconnaissance mapping of entire internal subnet topology; RW access allows remote reboot or configuration rewrite.',
        threatVector: 'Network Topology Enumeration & Unauthorized SNMP RW Modification'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? [
              'no snmp-server community public',
              'no snmp-server community private',
              'snmp-server group SECURE_CORP_GRP v3 priv',
              'snmp-server user sec_auditor SECURE_CORP_GRP v3 auth sha256 StrongAuthPass! priv aes 256 StrongPrivPass!'
            ]
          : vendor === 'juniper'
          ? [
              'delete snmp community public',
              'delete snmp community secret_netops',
              'set snmp v3 usm local-engine user sec_auditor authentication-sha authentication-password "StrongAuth@2024!"',
              'set snmp v3 usm local-engine user sec_auditor privacy-aes128 privacy-password "StrongPriv@2024!"'
            ]
          : vendor === 'fortinet'
          ? ['config system snmp community', ' delete 1', 'end', 'config system snmp user', ' edit "sec_admin"', '  set auth-proto sha256', '  set priv-proto aes256', ' next', 'end']
          : ['/snmp community remove [find name=public]'],
        explanation: 'Deprecate legacy SNMP v1/v2c cleartext communities and transition to SNMPv3 with SHA256 authentication and AES-256 privacy encryption.',
        rollbackCommands: vendor === 'cisco' ? ['snmp-server community public RO'] : ['set snmp community public']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 2.1.1', controlTitle: 'Disable Default SNMP Communities & Enforce SNMPv3' },
        { framework: 'DISA_STIG', frameworkName: 'DISA Network Device STIG', controlId: 'NET-082', controlTitle: 'Network device must not use default SNMP strings' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'IA-2(1)', controlTitle: 'Multi-Factor Authentication / Cryptographic Token Verification' }
      ],
      confidence: 0.99
    });
  }

  // Finding 4: Over-Permissive Any-Any Access Control Rule
  if (canonical.accessControl.overPermissiveAclFound) {
    findings.push({
      id: 'FIND-ACL-004',
      title: 'Over-Permissive Any-Any Inbound Access Control Rule',
      severity: 'CRITICAL',
      category: 'Access Control',
      evidence: vendor === 'cisco'
        ? 'access-list 101 permit ip any any'
        : vendor === 'juniper'
        ? 'policy allow-all-traffic { match { source-address any; destination-address any; } then { permit; } }'
        : vendor === 'fortinet'
        ? 'set srcaddr "all" \n set dstaddr "all" \n set action accept \n set utm-status disable'
        : vendor === 'paloalto'
        ? 'rules "Permit-All-Outbound" from any to any action allow'
        : 'add chain=forward action=accept comment="Forward everything unconditionally"',
      lineNumber: 30,
      explanation: {
        what: 'A catch-all perimeter firewall or ACL rule permits unrestricted bidirectional traffic without IP filtering or Deep Packet Inspection (UTM).',
        why: 'Violates the fundamental Principle of Least Privilege and Zero Trust architecture, allowing unauthorized external ingress.',
        impact: 'Permits lateral movement, direct command-and-control communication, and unrestricted exfiltration vectors.',
        threatVector: 'Perimeter Breach & Lateral Network Intrusion'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? [
              'no access-list 101 permit ip any any',
              'access-list 101 permit tcp 10.0.0.0 0.255.255.255 192.168.100.0 0.0.0.3 eq 443',
              'access-list 101 deny ip any any log-input'
            ]
          : vendor === 'juniper'
          ? [
              'delete security policies from-zone untrust to-zone trust policy allow-all-traffic',
              'set security policies from-zone untrust to-zone trust policy restrict-inbound match source-address CORP-NET destination-address DMZ-SRV application junos-https',
              'set security policies from-zone untrust to-zone trust policy restrict-inbound then permit',
              'set security policies from-zone untrust to-zone trust policy default-deny match source-address any destination-address any application any then reject'
            ]
          : vendor === 'fortinet'
          ? [
              'config firewall policy',
              ' edit 1',
              '  set srcaddr "CORP_INTERNAL"',
              '  set dstaddr "APPROVED_SERVICES"',
              '  set service "HTTPS" "SSH"',
              '  set utm-status enable',
              '  set ips-sensor "default"',
              '  set av-profile "default"',
              ' next',
              'end'
            ]
          : ['set rulebase security rules "Permit-All-Outbound" action deny'],
        explanation: 'Remove the wildcard permit rule, define explicit source/destination address objects, enable UTM inspection, and apply an explicit default deny with logging.',
        rollbackCommands: vendor === 'cisco' ? ['access-list 101 permit ip any any'] : ['set security policies permit-all']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 3.2.1', controlTitle: 'Enforce Explicit Boundary Protection and Deny-All Default' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'SC-7(5)', controlTitle: 'Boundary Protection / Deny by Default, Allow by Exception' },
        { framework: 'DISA_STIG', frameworkName: 'DISA Network Device STIG', controlId: 'NET-110', controlTitle: 'Traffic filter must drop unauthorized inbound packets' },
        { framework: 'PCI_DSS', frameworkName: 'PCI-DSS v4.0', controlId: 'Req 1.3.1', controlTitle: 'Restrict inbound and outbound traffic to strictly necessary services' }
      ],
      confidence: 0.97
    });
  }

  // Finding 5: Weak / Missing Password Encryption
  if (!canonical.authentication.passwordEncryptionEnabled || canonical.authentication.weakPasswordsDetected || canonical.authentication.rootLoginDirectSSH) {
    findings.push({
      id: 'FIND-AUTH-005',
      title: 'Weak Local Authentication & Plaintext Password Storage',
      severity: 'HIGH',
      category: 'Authentication & AAA',
      evidence: vendor === 'cisco'
        ? 'no service password-encryption\nenable password cisco123'
        : vendor === 'juniper'
        ? 'root-authentication { plain-text-password-value "Defence@2024!"; }\nroot-login allow;'
        : 'admin password plaintext / weak hash without lockout',
      lineNumber: 7,
      explanation: {
        what: 'Administrative credentials are stored using Type-0 plaintext or vulnerable legacy Type-7 reversible obfuscation.',
        why: 'Anyone with read access to device backup archives can instantly decode privileged executive passwords.',
        impact: 'Offline credential cracking, privilege escalation, and lateral authentication across mirrored network devices.',
        threatVector: 'Local Privilege Escalation via Weak Stored Secrets'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? [
              'service password-encryption',
              'no enable password',
              'enable algorithm-type sha256 secret StrongSecret@987!',
              'username admin privilege 15 algorithm-type sha256 secret AdminSecPass@2026!'
            ]
          : vendor === 'juniper'
          ? [
              'set system services ssh root-login deny',
              'set system root-authentication encrypted-password "$6$salt$hashedSecretString..."'
            ]
          : vendor === 'fortinet'
          ? ['config system global', ' set admin-lockout-threshold 3', ' set admin-lockout-duration 300', 'end']
          : ['/user set admin password="StrongUniquePass#2026"'],
        explanation: 'Enable irreversible SHA-256/Type-8/Type-9 password hashing and disable direct root SSH access.',
        rollbackCommands: vendor === 'cisco' ? ['no service password-encryption'] : ['set system services ssh root-login allow']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 1.2.1', controlTitle: 'Enforce Strong Cryptographic Password Hashing (Type 8/9 or Argon2)' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'IA-5(1)', controlTitle: 'Password-Based Authentication with Salted Hashing' },
        { framework: 'DISA_STIG', frameworkName: 'DISA Network Device STIG', controlId: 'NET-020', controlTitle: 'Device must protect authenticators against unauthorized disclosure' }
      ],
      confidence: 0.99
    });
  }

  // Finding 6: Missing Centralized Audit Syslog Forwarding
  if (!canonical.loggingMonitoring.syslogServerConfigured) {
    findings.push({
      id: 'FIND-LOG-006',
      title: 'Missing Centralized Remote Syslog / SIEM Forwarding',
      severity: 'MEDIUM',
      category: 'Logging & Monitoring',
      evidence: vendor === 'cisco'
        ? 'No "logging host" or "logging server" configured'
        : vendor === 'fortinet'
        ? 'config log syslogd setting \n set status disable'
        : 'Remote SIEM server undefined in configuration',
      lineNumber: 24,
      explanation: {
        what: 'Security event logs are stored strictly in volatile local memory buffers rather than shipped to a tamper-resistant SIEM.',
        why: 'In the event of device crash, power outage, or malicious log flushing by an attacker, forensic trails are permanently lost.',
        impact: 'Inability to detect active intrusions in real-time or perform post-incident breach forensics.',
        threatVector: 'Forensic Evasion & Undetected Malicious Activity'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? [
              'logging host 10.10.10.50 transport tls port 6514',
              'logging trap informational',
              'logging facility local7',
              'logging source-interface GigabitEthernet1/0/2'
            ]
          : vendor === 'juniper'
          ? [
              'set system syslog host 10.10.10.50 any info',
              'set system syslog host 10.10.10.50 match-all'
            ]
          : vendor === 'fortinet'
          ? [
              'config log syslogd setting',
              ' set status enable',
              ' set server "10.10.10.50"',
              ' set mode reliable',
              ' set port 6514',
              'end'
            ]
          : ['/system logging action add name=siem target=remote remote=10.10.10.50'],
        explanation: 'Configure TLS-encrypted remote syslog export to the Security Operations Center (SOC) SIEM indexer.',
        rollbackCommands: vendor === 'cisco' ? ['no logging host 10.10.10.50'] : ['set log syslogd status disable']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 2.2.1', controlTitle: 'Configure Centralized Remote Syslog Logging' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'AU-9', controlTitle: 'Protection of Audit Information' },
        { framework: 'DISA_STIG', frameworkName: 'DISA Network Device STIG', controlId: 'NET-140', controlTitle: 'Network device must transmit audit records to central server' },
        { framework: 'PCI_DSS', frameworkName: 'PCI-DSS v4.0', controlId: 'Req 10.5.1', controlTitle: 'Secure audit trails so they cannot be altered or deleted' }
      ],
      confidence: 0.95
    });
  }

  // Finding 7: Unauthenticated NTP Time Synchronization
  if (!canonical.loggingMonitoring.ntpAuthenticated) {
    findings.push({
      id: 'FIND-NTP-007',
      title: 'Unauthenticated NTP Synchronization / Missing Cryptographic Key',
      severity: 'MEDIUM',
      category: 'Logging & Monitoring',
      evidence: vendor === 'cisco'
        ? 'ntp server 10.10.10.1 (missing "ntp authenticate")'
        : 'ntp server without SHA authentication key',
      lineNumber: 26,
      explanation: {
        what: 'Device synchronizes time from network time servers without cryptographic HMAC-SHA authentication.',
        why: 'An adversary on the local network can spoof NTP UDP 123 packets (NTP replay/poisoning attack) to manipulate device system clocks.',
        impact: 'Time shifting invalidates X.509 TLS certificates, disrupts Kerberos ticket validation, and distorts forensic audit log sequencing.',
        threatVector: 'NTP Cache Poisoning & Timestamp Manipulation'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? [
              'ntp authenticate',
              'ntp authentication-key 1 sha1 SecretNtpKey@2026',
              'ntp trusted-key 1',
              'ntp server 10.10.10.1 key 1'
            ]
          : vendor === 'juniper'
          ? [
              'set system ntp authentication-key 1 type sha1 value "SecretNtpKey@2026"',
              'set system ntp trusted-key 1',
              'set system ntp server 192.168.20.10 key 1'
            ]
          : ['set system ntp-servers auth-key-id 1'],
        explanation: 'Enforce cryptographic key verification on all NTP peer associations.',
        rollbackCommands: vendor === 'cisco' ? ['no ntp authenticate'] : ['delete system ntp trusted-key']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 2.3.2', controlTitle: 'Enable NTP Cryptographic Authentication' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'AU-8(1)', controlTitle: 'Time Stamps / Synchronization with Authoritative Time Source' }
      ],
      confidence: 0.94
    });
  }

  // Finding 8: Missing Legal Warning / Banner MOTD
  if (!canonical.management.loginBannerConfigured) {
    findings.push({
      id: 'FIND-BANNER-008',
      title: 'Missing Legally Enforceable Unauthorized Access Warning Banner',
      severity: 'LOW',
      category: 'Service Hardening',
      evidence: 'No legal disclaimer banner found in configuration or empty banner string',
      lineNumber: 35,
      explanation: {
        what: 'Device lacks a standard authorized usage and legal disclaimer banner presented to incoming administrative sessions.',
        why: 'In legal and forensic court proceedings, lack of an explicit notice stating "Authorized Access Only" may hinder prosecution of unauthorized intruders.',
        impact: 'Weakened legal recourse against unauthorized access and compliance audit non-conformance.',
        threatVector: 'Compliance & Legal Prosecution Deficit'
      },
      remediation: {
        commands: vendor === 'cisco'
          ? [
              'banner motd ^C',
              '*******************************************************************************',
              '* WARNING: UNLAWFUL ACCESS TO THIS SYSTEM IS STRICTLY PROHIBITED BY LAW.       *',
              '* ALL ACTIVITIES ARE MONITORED AND LOGGED FOR SECURITY COMPLIANCE PURPOSES.  *',
              '*******************************************************************************',
              '^C'
            ]
          : vendor === 'juniper'
          ? ['set system login message "\\n***************************************************\\n* AUTHORIZED ACCESS ONLY - MONITORING IS ACTIVE *\\n***************************************************\\n"']
          : ['set deviceconfig system login-banner "AUTHORIZED USE ONLY"'],
        explanation: 'Configure a standard legal banner explicitly stating authorized access rules and continuous monitoring.',
        rollbackCommands: vendor === 'cisco' ? ['no banner motd'] : ['delete system login message']
      },
      controlMappings: [
        { framework: 'CIS_BENCHMARKS', frameworkName: 'CIS Benchmark v2.0', controlId: 'CIS 1.3.1', controlTitle: 'Configure Warning Banner for Remote Logins' },
        { framework: 'NIST_SP800_53', frameworkName: 'NIST SP 800-53 Rev 5', controlId: 'AC-8', controlTitle: 'System Use Notification' },
        { framework: 'DISA_STIG', frameworkName: 'DISA Network Device STIG', controlId: 'NET-030', controlTitle: 'Network device must display standard warning banner prior to login' }
      ],
      confidence: 0.96
    });
  }

  // Calculate Scores
  const totalWeight = 100;
  let penalty = 0;
  findings.forEach(f => {
    if (f.severity === 'CRITICAL') penalty += 20;
    else if (f.severity === 'HIGH') penalty += 12;
    else if (f.severity === 'MEDIUM') penalty += 7;
    else if (f.severity === 'LOW') penalty += 3;
  });

  const complianceScore = Math.max(12, Math.min(100, totalWeight - penalty));
  const riskScore = Math.min(100, Math.max(0, 100 - complianceScore));

  let complianceGrade: 'A' | 'B' | 'C' | 'D' | 'F' = 'F';
  if (complianceScore >= 90) complianceGrade = 'A';
  else if (complianceScore >= 80) complianceGrade = 'B';
  else if (complianceScore >= 68) complianceGrade = 'C';
  else if (complianceScore >= 50) complianceGrade = 'D';

  let riskLevel: Severity = 'LOW';
  if (riskScore >= 70) riskLevel = 'CRITICAL';
  else if (riskScore >= 45) riskLevel = 'HIGH';
  else if (riskScore >= 25) riskLevel = 'MEDIUM';

  const cisScore = Math.max(15, complianceScore - 4);
  const nistScore = Math.max(10, complianceScore + 2);
  const stigScore = Math.max(10, complianceScore - 8);
  const pciScore = Math.max(10, complianceScore - 2);

  // Generate SHA256-like unique deterministic audit evidence hash
  const timestamp = new Date().toISOString();
  const hashSeed = `${canonical.hostname}_${vendor}_${complianceScore}_${findings.length}_${timestamp}`;
  const auditEvidenceHash = '0x' + Array.from(hashSeed).map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('').slice(0, 32).padEnd(32, 'f');

  return {
    id: `AUDIT-${Date.now().toString().slice(-6)}`,
    timestamp,
    targetDeviceName: canonical.hostname || 'TARGET-GATEWAY',
    vendor,
    complianceScore,
    complianceGrade,
    riskScore,
    riskLevel,
    findings,
    frameworkScores: {
      CIS_BENCHMARKS: Math.min(100, cisScore),
      NIST_SP800_53: Math.min(100, nistScore),
      DISA_STIG: Math.min(100, stigScore),
      PCI_DSS: Math.min(100, pciScore),
    },
    canonicalModel: canonical,
    rawConfig,
    auditEvidenceHash,
    summaryText: `Audited ${canonical.hostname || 'device'} (${vendor.toUpperCase()}) across 4 compliance frameworks. Detected ${findings.filter(f => f.severity === 'CRITICAL').length} Critical, ${findings.filter(f => f.severity === 'HIGH').length} High, and ${findings.filter(f => f.severity === 'MEDIUM').length} Medium misconfigurations requiring remediation.`,
    isAiEnhanced: false
  };
}
